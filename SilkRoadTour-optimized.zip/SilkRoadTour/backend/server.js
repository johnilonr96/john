require("dotenv").config({ path: require("node:path").join(__dirname, ".env") });

const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
const path = require("node:path");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");

const app = express();
app.disable("x-powered-by");
// Set only when the hosting proxy topology is known; never trust arbitrary clients.
if (process.env.TRUST_PROXY_HOPS) {
    const hops = Number(process.env.TRUST_PROXY_HOPS);
    if (!Number.isInteger(hops) || hops < 1) throw new Error("Invalid TRUST_PROXY_HOPS");
    app.set("trust proxy", hops);
}
// Existing pages contain inline scripts. Enable a strict CSP after those are extracted.
app.use(helmet({ contentSecurityPolicy: false, strictTransportSecurity: process.env.NODE_ENV === "production" ? undefined : false }));

const PORT =
    Number(process.env.PORT) ||
    3000;

app.use(
    cors({
        origin(origin, callback) {
            const allowed = (process.env.ALLOWED_ORIGINS || "").split(",").map(value => value.trim()).filter(Boolean);
            callback(null, Boolean(origin && allowed.includes(origin)));
        }
    })
);

app.use(
    express.json({
        limit: "100kb"
    })
);

function requiredEnv(name) {
    const value =
        process.env[name];

    if (!value) {
        throw new Error(
            `Не задана переменная окружения ${name}`
        );
    }

    return value;
}

function createTransporter() {
    const port =
        Number(
            requiredEnv("SMTP_PORT")
        );

    const secure =
        String(
            process.env.SMTP_SECURE
        ).toLowerCase() === "true";

    return nodemailer.createTransport({
        host:
            requiredEnv("SMTP_HOST"),

        port,

        secure,

        auth: {
            user:
                requiredEnv("SMTP_USER"),

            pass:
                requiredEnv("SMTP_PASS")
        }
    });
}

function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function formatDate(value) {
    if (!value) {
        return "—";
    }

    const parts =
        String(value).split("-");

    if (parts.length !== 3) {
        return String(value);
    }

    return `${parts[2]}.${parts[1]}.${parts[0]}`;
}

app.get(
    "/api/health",
    (req, res) => {
        res.json({
            ok: true,
            service:
                "SilkRoad Tour email API"
        });
    }
);

app.post(
    "/api/send-booking-email",
    rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: "draft-8", legacyHeaders: false }),
    async (req, res) => {

        // This prototype accepts client-supplied booking data. Keep the public
        // email endpoint disabled in production until server-side bookings exist.
        if (process.env.NODE_ENV === "production") {
            return res.status(503).json({ ok: false, message: "Отправка писем недоступна до подключения серверного бронирования." });
        }

        const {
            email,
            fullName,
            bookingNumber,
            tourTitle,
            date,
            tourists
        } = req.body || {};

        const cleanEmail =
            String(email || "")
                .trim()
                .toLowerCase();

        if (
            !cleanEmail ||
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/
                .test(cleanEmail)
        ) {
            return res
                .status(400)
                .json({
                    ok: false,
                    message:
                        "Некорректный email."
                });
        }

        if (!bookingNumber || typeof bookingNumber !== "string" || bookingNumber.length > 64 || /[\r\n]/.test(bookingNumber)) {
            return res
                .status(400)
                .json({
                    ok: false,
                    message:
                        "Не указан номер бронирования."
                });
        }

        try {
            const transporter =
                createTransporter();

            const sender =
                process.env.MAIL_FROM ||
                process.env.SMTP_USER;

            const safeName =
                escapeHtml(
                    fullName || "турист"
                );

            const safeBooking =
                escapeHtml(
                    bookingNumber
                );

            const safeTour =
                escapeHtml(
                    tourTitle || "—"
                );

            const safeDate =
                escapeHtml(
                    formatDate(date)
                );

            const safeTourists =
                escapeHtml(
                    Number(tourists) || 1
                );

            await transporter.sendMail({
                from:
                    sender,

                to:
                    cleanEmail,

                subject:
                    `SilkRoad Tour — бронирование ${bookingNumber}`,

                text:
`Здравствуйте, ${fullName || "турист"}!

Ваше бронирование успешно создано.

Номер брони: ${bookingNumber}
Тур: ${tourTitle || "—"}
Дата: ${formatDate(date)}
Количество туристов: ${Number(tourists) || 1}

Сохраните номер брони. Он понадобится для раздела «Моё бронирование».

SilkRoad Tour`,

                html:
`<!doctype html>
<html lang="ru">
<body style="margin:0;padding:24px;background:#f5f7fa;font-family:Arial,sans-serif;color:#182230;">
    <div style="max-width:620px;margin:0 auto;background:#ffffff;border-radius:16px;padding:32px;">
        <h2 style="margin:0 0 16px;">Бронирование успешно создано ✓</h2>

        <p>Здравствуйте, ${safeName}!</p>

        <p>Ваш номер брони:</p>

        <div style="
            display:inline-block;
            padding:14px 22px;
            background:#f0f3f7;
            border-radius:12px;
            font-size:28px;
            font-weight:700;
            letter-spacing:1px;">
            ${safeBooking}
        </div>

        <div style="margin-top:24px;line-height:1.7;">
            <div><strong>Тур:</strong> ${safeTour}</div>
            <div><strong>Дата:</strong> ${safeDate}</div>
            <div><strong>Туристов:</strong> ${safeTourists}</div>
        </div>

        <p style="margin-top:24px;">
            Сохраните номер брони. Он понадобится для раздела «Моё бронирование».
        </p>

        <p style="margin-top:28px;color:#667085;">
            SilkRoad Tour
        </p>
    </div>
</body>
</html>`
            });

            return res.json({
                ok: true,
                message:
                    "Письмо отправлено."
            });

        } catch (error) {

            console.error("Ошибка отправки письма:", error.code || "MAIL_ERROR");

            return res
                .status(500)
                .json({
                    ok: false,
                    message:
                        "Не удалось отправить письмо."
                });
        }
    }
);

app.use("/api", (req, res) => res.status(404).json({ ok: false, message: "API endpoint not found" }));

const root = path.resolve(__dirname, "..");
app.use("/assets", express.static(path.join(root, "assets"), { maxAge: "1h", dotfiles: "deny" }));
app.get("/", (req, res) => res.sendFile(path.join(root, "index.html")));
app.get("/index.html", (req, res) => res.sendFile(path.join(root, "index.html")));
app.use("/pages", express.static(path.join(root, "pages"), { dotfiles: "deny", index: false }));
app.use((req, res) => res.status(404).sendFile(path.join(root, "404.html")));
app.use((error, req, res, next) => {
    const status = error.type === "entity.too.large" ? 413 : error instanceof SyntaxError && "body" in error ? 400 : 500;
    res.status(status).json({ ok: false, message: status === 500 ? "Внутренняя ошибка сервера." : "Некорректный запрос." });
});

if (require.main === module) {
    const server = app.listen(PORT, () => console.log(`SilkRoad Tour запущен, порт ${PORT}`));
    for (const signal of ["SIGTERM", "SIGINT"]) {
        process.on(signal, () => {
            server.close(() => process.exit(0));
            setTimeout(() => process.exit(1), 10000).unref();
        });
    }
}
module.exports = app;
