const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const app = require("../server");

let server;
let origin;
before(async () => {
    server = app.listen(0, "127.0.0.1");
    await new Promise(resolve => server.once("listening", resolve));
    origin = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise(resolve => { server.closeAllConnections(); server.close(resolve); }));

test("single-origin server delivers the catalog, local icons and API", async () => {
    const home = await fetch(origin);
    assert.equal(home.status, 200);
    assert.match(await home.text(), /vendor\/lucide\/lucide.min.js/);
    assert.equal(home.headers.get("x-content-type-options"), "nosniff");
    assert.equal(home.headers.get("x-powered-by"), null);
    for (const route of ["/pages/tour.html", "/assets/vendor/lucide/lucide.min.js", "/assets/css/responsive.css"]) {
        const response = await fetch(origin + route);
        assert.equal(response.status, 200, route);
        assert.ok((await response.text()).length > 100);
    }
    const health = await fetch(origin + "/api/health");
    assert.equal((await health.json()).ok, true);
});

test("server files and credentials cannot be downloaded through static routes", async () => {
    for (const route of ["/backend/server.js", "/backend/.env", "/backend/package.json", "/.git/config", "/assets/.env"]) {
        const response = await fetch(origin + route);
        assert.equal(response.status, 404, route);
    }
    const missing = await fetch(origin + "/missing-page");
    assert.equal(missing.status, 404);
    assert.match(await missing.text(), /Страница не найдена/);
});

test("API returns useful JSON errors and does not grant arbitrary CORS access", async () => {
    const response = await fetch(origin + "/api/no-such-endpoint");
    assert.equal(response.status, 404);
    assert.equal((await response.json()).ok, false);
    const health = await fetch(origin + "/api/health", { headers: { Origin: "https://untrusted.example" } });
    assert.equal(health.headers.get("access-control-allow-origin"), null);
    const malformed = await fetch(origin + "/api/send-booking-email", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: "{"
    });
    assert.equal(malformed.status, 400);
    assert.equal((await malformed.json()).ok, false);
});

test("unverified client-supplied email bookings are disabled in production", async () => {
    const previous = process.env.NODE_ENV;
    process.env.NODE_ENV = "production";
    try {
        const response = await fetch(origin + "/api/send-booking-email", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: "test@example.com", bookingNumber: "test-booking" })
        });
        assert.equal(response.status, 503);
        assert.equal((await response.json()).ok, false);
    } finally {
        if (previous === undefined) delete process.env.NODE_ENV;
        else process.env.NODE_ENV = previous;
    }
});

test("email validation rejects bad input and repeated requests are rate limited", async () => {
    const previous = process.env.NODE_ENV;
    process.env.NODE_ENV = "test";
    try {
        let limited = false;
        for (let index = 0; index < 6; index++) {
            const response = await fetch(origin + "/api/send-booking-email", {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email: "invalid" })
            });
            assert.ok([400, 429].includes(response.status));
            if (response.status === 429) limited = true;
        }
        assert.equal(limited, true);
    } finally {
        if (previous === undefined) delete process.env.NODE_ENV;
        else process.env.NODE_ENV = previous;
    }
});
