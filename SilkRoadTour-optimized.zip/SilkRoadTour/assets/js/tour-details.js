(function () {
    "use strict";

    const BOOKING_EMAIL_API =
        "/api/send-booking-email";

    async function sendBookingEmail(booking) {
        const response = await fetch(
            BOOKING_EMAIL_API,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email:
                        booking?.tourist?.email || "",
                    fullName:
                        booking?.tourist?.fullName || "",
                    bookingNumber:
                        getBookingNumber(booking?.id),
                    tourTitle:
                        booking?.tourTitle || "",
                    date:
                        booking?.date || "",
                    tourists:
                        Number(booking?.tourists) || 1
                })
            }
        );

        let data = {};

        try {
            data = await response.json();
        } catch (_) {
            // Сервер может вернуть ответ без JSON.
        }

        if (!response.ok) {
            throw new Error(
                data?.message ||
                "Не удалось отправить письмо."
            );
        }

        return data;
    }

    function readJson(key, fallback) {
        try {
            const value = JSON.parse(localStorage.getItem(key));
            return value ?? fallback;
        } catch (error) {
            console.error(`Ошибка чтения ${key}:`, error);
            return fallback;
        }
    }

    function formatDate(value) {
        if (!value) return "—";
        const parts = String(value).split("-");
        if (parts.length !== 3) return value;
        return `${parts[2]}.${parts[1]}.${parts[0]}`;
    }

    function getTourPrice(tour) {
        const price = tour?.price || {};
        const adult = Number(price.adult) || 0;
        const servicesTotal = Array.isArray(price.services)
            ? price.services.reduce(
                (sum, service) => sum + (Number(service?.price) || 0),
                0
            )
            : 0;

        return {
            value: adult + servicesTotal,
            currency: price.currency || "USD"
        };
    }

    function getBookingNumber(id) {
        if (!id) return "—";
        return `#${String(id).slice(-8)}`;
    }

    function createSuccessModal() {
        let modal = document.getElementById("bookingSuccessModal");

        if (modal) {
            return modal;
        }

        modal = document.createElement("div");
        modal.className = "booking-modal";
        modal.id = "bookingSuccessModal";
        modal.hidden = true;
        modal.setAttribute("role", "dialog");
        modal.setAttribute("aria-modal", "true");
        modal.setAttribute("aria-labelledby", "bookingSuccessHeading");

        modal.innerHTML = `
            <div class="booking-modal__overlay" data-booking-success-close></div>

            <div class="booking-modal__window" style="max-width: 520px;">
                <div class="booking-modal__header">
                    <div>
                        <h2 id="bookingSuccessHeading">Бронирование успешно создано ✓</h2>
                        <p>Сохраните номер брони — он понадобится для просмотра и управления бронированием.</p>
                    </div>

                    <button
                        type="button"
                        class="booking-modal__close"
                        id="bookingSuccessClose"
                        aria-label="Закрыть">
                        ×
                    </button>
                </div>

                <div class="booking-modal__body" style="text-align: center;">
                    <p style="margin: 0 0 10px; color: #667085;">
                        Ваш номер брони
                    </p>

                    <div
                        id="bookingSuccessNumber"
                        style="
                            display: inline-block;
                            padding: 14px 22px;
                            border-radius: 12px;
                            background: #f5f7fa;
                            font-size: 28px;
                            font-weight: 800;
                            letter-spacing: 1px;
                        ">
                        —
                    </div>

                    <p
                        id="bookingEmailStatus"
                        style="
                            margin: 16px 0 0;
                            color: #667085;
                            line-height: 1.5;
                        ">
                    </p>
                </div>

                <div class="booking-modal__footer">
                    <button
                        type="button"
                        class="btn booking-modal__cancel"
                        id="bookingSuccessDone">
                        Закрыть
                    </button>

                    <a
                        class="btn btn-primary"
                        id="bookingSuccessManage"
                        href="my-booking.html">
                        Моё бронирование
                    </a>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        return modal;
    }

    function initBookingModal() {
        const bookingModal = document.getElementById("bookingModal");
        const bookingButton = document.getElementById("bookingButton");
        const bookingForm = document.getElementById("bookingTouristForm");
        const bookingModalClose = document.getElementById("bookingModalClose");
        const bookingModalCancel = document.getElementById("bookingModalCancel");
        const bookingModalOverlay = bookingModal?.querySelector("[data-booking-modal-close]");

        const successModal = createSuccessModal();
        const successNumber = document.getElementById("bookingSuccessNumber");
        const successEmailStatus = document.getElementById("bookingEmailStatus");
        const successClose = document.getElementById("bookingSuccessClose");
        const successDone = document.getElementById("bookingSuccessDone");
        const successManage = document.getElementById("bookingSuccessManage");
        const successOverlay = successModal?.querySelector("[data-booking-success-close]");

        let currentSuccessBooking = null;

        const tourDate = document.getElementById("tourDate");
        const touristsSelect = document.getElementById("touristsSelect");

        const touristFullName = document.getElementById("touristFullName");
        const touristPhone = document.getElementById("touristPhone");
        const touristEmail = document.getElementById("touristEmail");
        const touristCountry = document.getElementById("touristCountry");
        const formError = document.getElementById("bookingFormError");

        const modalTitle = document.getElementById("bookingModalTitle");
        const modalDate = document.getElementById("bookingModalDate");
        const modalTourists = document.getElementById("bookingModalTourists");
        const modalPrice = document.getElementById("bookingModalPrice");

        if (!bookingModal || !bookingButton || !bookingForm || !tourDate) {
            console.error("❌ Не найдены обязательные элементы бронирования.");
            return;
        }

        function updateBookingButton() {
            const selectedDate = tourDate.value;
            const minDate = tourDate.min;
            const valid = Boolean(selectedDate) && (!minDate || selectedDate >= minDate);

            bookingButton.disabled = !valid;
            bookingButton.textContent = valid ? "Забронировать" : "Выберите дату";
        }

        tourDate.addEventListener("change", updateBookingButton);
        tourDate.addEventListener("input", updateBookingButton);
        updateBookingButton();

        function showError(message) {
            if (!formError) return;
            formError.textContent = message;
            formError.hidden = !message;
        }

        function openBookingModal() {
            if (!tourDate.value) {
                updateBookingButton();
                tourDate.focus();
                return;
            }

            const tour = readJson("viewingTour", {});
            const title =
                tour?.basic?.title ||
                document.getElementById("tourTitle")?.textContent?.trim() ||
                "Без названия";

            const tourists = Number(touristsSelect?.value) || 1;
            const priceData = getTourPrice(tour);

            if (modalTitle) modalTitle.textContent = title;
            if (modalDate) modalDate.textContent = formatDate(tourDate.value);
            if (modalTourists) modalTourists.textContent = String(tourists);
            if (modalPrice) modalPrice.textContent = `${priceData.value} ${priceData.currency}`;

            showError("");
            bookingModal.hidden = false;
            document.body.classList.add("booking-modal-open");

            setTimeout(() => touristFullName?.focus(), 0);
        }

        function closeBookingModal() {
            bookingModal.hidden = true;
            document.body.classList.remove("booking-modal-open");
            showError("");
        }

        function openSuccessModal(booking, emailSent) {
            if (!successModal) return;

            currentSuccessBooking = booking;

            if (successNumber) {
                successNumber.textContent = getBookingNumber(booking.id);
            }

            if (successEmailStatus) {
                if (emailSent === true) {
                    successEmailStatus.textContent =
                        `Код бронирования отправлен на ${booking?.tourist?.email || "указанный email"}.`;
                } else if (emailSent === false) {
                    successEmailStatus.textContent =
                        "Бронирование создано, но письмо не удалось отправить. Сохраните номер брони на экране.";
                } else {
                    successEmailStatus.textContent = "";
                }
            }

            successModal.hidden = false;
            document.body.classList.add("booking-modal-open");
        }

        function closeSuccessModal() {
            if (!successModal) return;

            successModal.hidden = true;
            document.body.classList.remove("booking-modal-open");
        }

        bookingButton.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (bookingButton.disabled) {
                updateBookingButton();
                return;
            }

            openBookingModal();
        });

        bookingModalClose?.addEventListener("click", closeBookingModal);
        bookingModalCancel?.addEventListener("click", closeBookingModal);
        bookingModalOverlay?.addEventListener("click", closeBookingModal);

        successClose?.addEventListener("click", closeSuccessModal);
        successDone?.addEventListener("click", closeSuccessModal);
        successOverlay?.addEventListener("click", closeSuccessModal);

        successManage?.addEventListener("click", function () {
            if (!currentSuccessBooking) {
                return;
            }

            try {
                sessionStorage.setItem(
                    "bookingQuickAccess",
                    JSON.stringify({
                        id: currentSuccessBooking.id,
                        email: currentSuccessBooking?.tourist?.email || ""
                    })
                );
            } catch (error) {
                console.error(
                    "Не удалось подготовить быстрый переход к бронированию:",
                    error
                );
            }
        });

        document.addEventListener("keydown", function (event) {
            if (event.key !== "Escape") {
                return;
            }

            if (successModal && !successModal.hidden) {
                closeSuccessModal();
                return;
            }

            if (!bookingModal.hidden) {
                closeBookingModal();
            }
        });

        bookingForm.addEventListener("submit", async function (event) {
            event.preventDefault();
            showError("");

            const fullName = touristFullName?.value.trim() || "";
            const phone = touristPhone?.value.trim() || "";
            const email = touristEmail?.value.trim().toLowerCase() || "";
            const country = touristCountry?.value.trim() || "";

            if (!fullName || !phone || !email || !country) {
                showError("Заполните все поля.");
                return;
            }

            if (!bookingForm.checkValidity()) {
                bookingForm.reportValidity();
                return;
            }

            const tour = readJson("viewingTour", {});
            const priceData = getTourPrice(tour);
            const title =
                tour?.basic?.title ||
                document.getElementById("tourTitle")?.textContent?.trim() ||
                "Без названия";

            const booking = {
                id: Date.now(),
                createdAt: new Date().toISOString(),
                status: "new",
                tourist: {
                    fullName,
                    phone,
                    email,
                    country
                },
                tourTitle: title,
                date: tourDate.value,
                tourists: Number(touristsSelect?.value) || 1,
                price: priceData.value,
                currency: priceData.currency
            };

            const storedBookings = readJson("bookings", []);
            const bookings = Array.isArray(storedBookings) ? storedBookings : [];
            bookings.push(booking);

            try {
                localStorage.setItem("bookings", JSON.stringify(bookings));
            } catch (error) {
                console.error("Ошибка сохранения бронирования:", error);
                showError("Не удалось сохранить бронирование. Попробуйте ещё раз.");
                return;
            }

            bookingForm.reset();
            closeBookingModal();

            bookingButton.textContent = "Забронировано ✓";
            bookingButton.disabled = true;

            let emailSent = false;

            try {
                await sendBookingEmail(booking);
                emailSent = true;

                console.log(
                    "✅ Код бронирования отправлен на email:",
                    booking.tourist.email
                );
            } catch (error) {
                console.error(
                    "Ошибка отправки email:",
                    error
                );
            }

            openSuccessModal(
                booking,
                emailSent
            );

            console.log("✅ Бронирование сохранено:", booking);
        });

        console.log("✅ Модуль бронирования подключён.");
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initBookingModal);
    } else {
        initBookingModal();
    }
})();
