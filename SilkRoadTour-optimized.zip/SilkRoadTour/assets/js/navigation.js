/* Progressive enhancement: links remain available if JavaScript is disabled. */
document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector(".header");
    const navigation = header?.querySelector(".navigation");
    if (!navigation) return;
    const actions = header.querySelector(".header-right");
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "nav-toggle";
    toggle.textContent = "Меню";
    toggle.setAttribute("aria-expanded", "false");
    navigation.id ||= "site-navigation";
    toggle.setAttribute("aria-controls", navigation.id);
    navigation.before(toggle);
    header.setAttribute("data-mobile-menu", "");
    function setOpen(open) {
        toggle.setAttribute("aria-expanded", String(open));
        toggle.textContent = open ? "Закрыть меню" : "Меню";
        navigation.classList.toggle("is-open", open);
        actions?.classList.toggle("is-open", open);
    }
    toggle.addEventListener("click", () => setOpen(toggle.getAttribute("aria-expanded") !== "true"));
    header.addEventListener("keydown", event => {
        if (event.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
            setOpen(false);
            toggle.focus();
        }
    });
});
