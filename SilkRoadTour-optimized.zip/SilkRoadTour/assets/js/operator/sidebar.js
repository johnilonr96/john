class Sidebar {

    constructor() {

        this.sidebar = document.querySelector(".sidebar");
        this.toggleBtn = document.querySelector(".sidebar-toggle");
        this.overlay = document.querySelector(".sidebar-overlay");

        this.breakpoint = 992;

        this.init();

    }

    init() {

        this.restoreState();

        this.highlightCurrentPage();

        this.bindEvents();

        window.addEventListener("resize", () => {

            this.handleResize();

        });

    }

    bindEvents() {

        if (this.toggleBtn) {

            this.toggleBtn.addEventListener("click", () => {

                this.toggle();

            });

        }

        if (this.overlay) {

            this.overlay.addEventListener("click", () => {

                this.closeMobile();

            });

        }

        document.addEventListener("keydown", (e) => {

            if (e.key === "Escape") {

                this.closeMobile();

            }

        });

    }

    toggle() {

        if (window.innerWidth <= this.breakpoint) {

            this.sidebar.classList.toggle("mobile-open");

            if (this.overlay) {

                this.overlay.classList.toggle("active");

            }

            return;

        }

        this.sidebar.classList.toggle("collapsed");

        localStorage.setItem(

            "operator-sidebar",

            this.sidebar.classList.contains("collapsed")

        );

    }

    closeMobile() {

        if (!this.sidebar) return;

        this.sidebar.classList.remove("mobile-open");

        if (this.overlay) {

            this.overlay.classList.remove("active");

        }

    }

    restoreState() {

        if (!this.sidebar) return;

        if (window.innerWidth <= this.breakpoint) {

            return;

        }

        const collapsed =

            localStorage.getItem("operator-sidebar") === "true";

        if (collapsed) {

            this.sidebar.classList.add("collapsed");

        }

    }

    handleResize() {

        if (window.innerWidth > this.breakpoint) {

            this.closeMobile();

        }

    }

    highlightCurrentPage() {

        const current = window.location.pathname
            .split("/")
            .pop();

        document.querySelectorAll(".sidebar nav a").forEach(link => {

            link.classList.remove("active");

            const href = link.getAttribute("href");

            if (!href) return;

            if (href === current) {

                link.classList.add("active");

            }

        });

    }

}

document.addEventListener("DOMContentLoaded", () => {

    new Sidebar();

});