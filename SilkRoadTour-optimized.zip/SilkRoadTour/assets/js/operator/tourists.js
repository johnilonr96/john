document.addEventListener(
    "DOMContentLoaded",
    function () {

        const STORAGE_KEY =
            "bookings";

        const table =
            document.querySelector(
                ".tourists-table"
            );

        const tableBody =
            document.getElementById(
                "touristsTableBody"
            );

        const emptyState =
            document.getElementById(
                "touristsEmpty"
            );

        const searchInput =
            document.getElementById(
                "touristSearch"
            );

        const statusFilter =
            document.getElementById(
                "touristStatusFilter"
            );

        const exportButton =
            document.getElementById(
                "exportTourists"
            );

        const totalTourists =
            document.getElementById(
                "totalTourists"
            );

        const activeTourists =
            document.getElementById(
                "activeTourists"
            );

        const completedTourists =
            document.getElementById(
                "completedTourists"
            );

        const repeatTourists =
            document.getElementById(
                "repeatTourists"
            );


        let touristBookings = [];


        function readBookings() {

            try {

                const data =
                    JSON.parse(
                        localStorage.getItem(
                            STORAGE_KEY
                        )
                    );

                const bookings =
                    Array.isArray(data)
                        ? data
                        : [];

                touristBookings =
                    bookings.filter(
                        item =>
                            item &&
                            item.tourist &&
                            (
                                item.tourist.fullName ||
                                item.tourist.phone ||
                                item.tourist.email
                            )
                    );

            } catch (error) {

                console.error(
                    "Ошибка чтения bookings:",
                    error
                );

                touristBookings = [];
            }
        }


        function escapeHtml(value) {

            return String(
                value ?? ""
            )
                .replaceAll("&", "&amp;")
                .replaceAll("<", "&lt;")
                .replaceAll(">", "&gt;")
                .replaceAll('"', "&quot;")
                .replaceAll("'", "&#039;");
        }


        function formatDate(value) {

            if (!value) {
                return "—";
            }

            const parts =
                String(value)
                    .split("-");

            if (
                parts.length !== 3
            ) {
                return value;
            }

            return (
                parts[2] +
                "." +
                parts[1] +
                "." +
                parts[0]
            );
        }


        function bookingNumber(id) {

            if (!id) {
                return "—";
            }

            return (
                "#" +
                String(id).slice(-8)
            );
        }


        function normalizedStatus(
            booking
        ) {

            if (
                booking.status ===
                "cancelled"
            ) {
                return "cancelled";
            }

            if (
                booking.status ===
                "completed"
            ) {
                return "completed";
            }

            if (
                booking.date
            ) {

                const tourDate =
                    new Date(
                        `${booking.date}T23:59:59`
                    );

                if (
                    !Number.isNaN(
                        tourDate.getTime()
                    ) &&
                    tourDate <
                        new Date()
                ) {

                    return "completed";
                }
            }

            if (
                booking.status ===
                "confirmed"
            ) {
                return "confirmed";
            }

            return "new";
        }


        function statusText(status) {

            if (
                status === "confirmed"
            ) {
                return "Подтверждено";
            }

            if (
                status === "completed"
            ) {
                return "Завершено";
            }

            if (
                status === "cancelled"
            ) {
                return "Отменено";
            }

            return "Новое";
        }


        function getInitials(name) {

            const parts =
                String(name || "")
                    .trim()
                    .split(/\s+/)
                    .filter(Boolean);

            if (
                parts.length === 0
            ) {
                return "Т";
            }

            return parts
                .slice(0, 2)
                .map(
                    part =>
                        part.charAt(0)
                            .toUpperCase()
                )
                .join("");
        }


        function travellerCount(
            booking
        ) {

            return (
                Number(
                    booking.tourists
                ) || 1
            );
        }


        function identityKey(
            booking
        ) {

            const email =
                booking.tourist?.email
                    ?.trim()
                    .toLowerCase();

            if (email) {
                return `email:${email}`;
            }

            const phone =
                booking.tourist?.phone
                    ?.replace(
                        /\D/g,
                        ""
                    );

            if (phone) {
                return `phone:${phone}`;
            }

            return (
                "name:" +
                (
                    booking.tourist
                        ?.fullName ||
                    ""
                )
                    .trim()
                    .toLowerCase()
            );
        }


        function updateStats() {

            const total =
                touristBookings.reduce(
                    (sum, booking) =>
                        sum +
                        travellerCount(
                            booking
                        ),
                    0
                );

            const active =
                touristBookings
                    .filter(
                        booking => {
                            const status =
                                normalizedStatus(
                                    booking
                                );

                            return (
                                status ===
                                    "new" ||
                                status ===
                                    "confirmed"
                            );
                        }
                    )
                    .reduce(
                        (sum, booking) =>
                            sum +
                            travellerCount(
                                booking
                            ),
                        0
                    );

            const completed =
                touristBookings
                    .filter(
                        booking =>
                            normalizedStatus(
                                booking
                            ) ===
                            "completed"
                    )
                    .reduce(
                        (sum, booking) =>
                            sum +
                            travellerCount(
                                booking
                            ),
                        0
                    );


            const identityCounts =
                new Map();

            touristBookings.forEach(
                booking => {

                    const key =
                        identityKey(
                            booking
                        );

                    if (!key) {
                        return;
                    }

                    identityCounts.set(
                        key,
                        (
                            identityCounts.get(
                                key
                            ) || 0
                        ) + 1
                    );
                }
            );


            const repeat =
                [...identityCounts.values()]
                    .filter(
                        count =>
                            count > 1
                    )
                    .length;


            if (totalTourists) {
                totalTourists.textContent =
                    total;
            }

            if (activeTourists) {
                activeTourists.textContent =
                    active;
            }

            if (completedTourists) {
                completedTourists.textContent =
                    completed;
            }

            if (repeatTourists) {
                repeatTourists.textContent =
                    repeat;
            }
        }


        function filteredBookings() {

            const query =
                searchInput?.value
                    .trim()
                    .toLowerCase() ||
                "";

            const filter =
                statusFilter?.value ||
                "all";


            return touristBookings
                .filter(
                    booking => {

                        const status =
                            normalizedStatus(
                                booking
                            );

                        const statusMatch =
                            filter === "all" ||
                            filter === status;

                        const tourist =
                            booking.tourist ||
                            {};

                        const searchSource =
                            [
                                tourist.fullName,
                                tourist.phone,
                                tourist.email,
                                tourist.country,
                                booking.tourTitle,
                                bookingNumber(
                                    booking.id
                                )
                            ]
                                .join(" ")
                                .toLowerCase();

                        const searchMatch =
                            !query ||
                            searchSource.includes(
                                query
                            );

                        return (
                            statusMatch &&
                            searchMatch
                        );
                    }
                )
                .sort(
                    (a, b) => {

                        const aTime =
                            new Date(
                                a.createdAt ||
                                0
                            ).getTime() ||
                            Number(a.id) ||
                            0;

                        const bTime =
                            new Date(
                                b.createdAt ||
                                0
                            ).getTime() ||
                            Number(b.id) ||
                            0;

                        return (
                            bTime -
                            aTime
                        );
                    }
                );
        }


        function render() {

            updateStats();

            if (
                !tableBody ||
                !emptyState
            ) {
                return;
            }

            const list =
                filteredBookings();

            tableBody.innerHTML =
                "";


            if (
                touristBookings.length ===
                0
            ) {

                if (table) {
                    table.hidden =
                        true;
                }

                emptyState.hidden =
                    false;

                emptyState.querySelector(
                    "h3"
                ).textContent =
                    "Туристов пока нет";

                emptyState.querySelector(
                    "p"
                ).textContent =
                    "После оформления бронирования информация о туристе появится здесь.";

                return;
            }


            if (
                list.length === 0
            ) {

                if (table) {
                    table.hidden =
                        true;
                }

                emptyState.hidden =
                    false;

                emptyState.querySelector(
                    "h3"
                ).textContent =
                    "Ничего не найдено";

                emptyState.querySelector(
                    "p"
                ).textContent =
                    "Измените поисковый запрос или фильтр.";

                return;
            }


            if (table) {
                table.hidden =
                    false;
            }

            emptyState.hidden =
                true;


            list.forEach(
                booking => {

                    const tourist =
                        booking.tourist ||
                        {};

                    const status =
                        normalizedStatus(
                            booking
                        );

                    const tr =
                        document.createElement(
                            "tr"
                        );

                    tr.dataset.id =
                        booking.id;

                    tr.innerHTML = `
                        <td>
                            <div class="tourist-profile">
                                <div class="tourist-avatar">
                                    ${escapeHtml(
                                        getInitials(
                                            tourist.fullName
                                        )
                                    )}
                                </div>
                                <div>
                                    <span class="tourist-name">
                                        ${escapeHtml(
                                            tourist.fullName ||
                                            "Без имени"
                                        )}
                                    </span>
                                    <span class="tourist-country">
                                        ${escapeHtml(
                                            tourist.country ||
                                            "Страна не указана"
                                        )}
                                    </span>
                                </div>
                            </div>
                        </td>

                        <td>
                            <div class="tourist-contact">
                                <span>
                                    ${escapeHtml(
                                        tourist.phone ||
                                        "—"
                                    )}
                                </span>
                                <span>
                                    ${escapeHtml(
                                        tourist.email ||
                                        "—"
                                    )}
                                </span>
                            </div>
                        </td>

                        <td>
                            ${escapeHtml(
                                booking.tourTitle ||
                                "Без названия"
                            )}
                        </td>

                        <td>
                            ${escapeHtml(
                                formatDate(
                                    booking.date
                                )
                            )}
                        </td>

                        <td>
                            ${travellerCount(
                                booking
                            )}
                        </td>

                        <td>
                            <span
                                class="tourist-status tourist-status-${status}">
                                ${escapeHtml(
                                    statusText(
                                        status
                                    )
                                )}
                            </span>
                        </td>

                        <td>
                            ${escapeHtml(
                                bookingNumber(
                                    booking.id
                                )
                            )}
                        </td>

                        <td>
                            <div class="tourist-actions">
                                <button
                                    type="button"
                                    class="tourist-action-btn"
                                    data-action="view"
                                    title="Подробнее">
                                    👁
                                </button>
                            </div>
                        </td>
                    `;

                    tableBody.appendChild(
                        tr
                    );
                }
            );
        }


        function getBookingById(id) {

            return touristBookings.find(
                booking =>
                    String(
                        booking.id
                    ) ===
                    String(id)
            );
        }


        function ensureDetailsModal() {

            let modal =
                document.getElementById(
                    "touristDetailsModal"
                );

            if (modal) {
                return modal;
            }


            modal =
                document.createElement(
                    "div"
                );

            modal.id =
                "touristDetailsModal";

            modal.className =
                "tourist-details-modal";

            modal.hidden =
                true;

            modal.innerHTML = `
                <div
                    class="tourist-details-modal__overlay"
                    data-tourist-modal-close>
                </div>

                <div
                    class="tourist-details-modal__window"
                    role="dialog"
                    aria-modal="true">

                    <div class="tourist-details-modal__header">
                        <div>
                            <small>Карточка туриста</small>
                            <h3 id="touristDetailsName">—</h3>
                        </div>

                        <button
                            type="button"
                            class="tourist-details-modal__close"
                            data-tourist-modal-close>
                            ×
                        </button>
                    </div>

                    <div class="tourist-details-grid">

                        <div>
                            <span>Телефон</span>
                            <strong id="touristDetailsPhone">—</strong>
                        </div>

                        <div>
                            <span>Email</span>
                            <strong id="touristDetailsEmail">—</strong>
                        </div>

                        <div>
                            <span>Страна</span>
                            <strong id="touristDetailsCountry">—</strong>
                        </div>

                        <div>
                            <span>Статус</span>
                            <strong id="touristDetailsStatus">—</strong>
                        </div>

                        <div class="tourist-details-wide">
                            <span>Тур</span>
                            <strong id="touristDetailsTour">—</strong>
                        </div>

                        <div>
                            <span>Дата тура</span>
                            <strong id="touristDetailsDate">—</strong>
                        </div>

                        <div>
                            <span>Количество туристов</span>
                            <strong id="touristDetailsCount">—</strong>
                        </div>

                        <div class="tourist-details-wide">
                            <span>№ бронирования</span>
                            <strong id="touristDetailsBooking">—</strong>
                        </div>

                    </div>

                    <div class="tourist-history">

                        <div class="tourist-history__header">
                            <div>
                                <small>История клиента</small>
                                <h4>Бронирования туриста</h4>
                            </div>

                            <strong id="touristDetailsTripsCount">0</strong>
                        </div>

                        <div
                            class="tourist-history__list"
                            id="touristDetailsHistory">
                        </div>

                    </div>

                </div>
            `;


            document.body.appendChild(
                modal
            );


            modal.addEventListener(
                "click",
                event => {

                    if (
                        event.target.closest(
                            "[data-tourist-modal-close]"
                        )
                    ) {

                        modal.hidden =
                            true;

                        document.body.classList.remove(
                            "tourist-modal-open"
                        );
                    }
                }
            );


            return modal;
        }


        function openDetails(id) {

            const booking =
                getBookingById(id);

            if (!booking) {
                return;
            }

            const modal =
                ensureDetailsModal();

            const tourist =
                booking.tourist ||
                {};

            const status =
                normalizedStatus(
                    booking
                );


            const values = {

                touristDetailsName:
                    tourist.fullName ||
                    "Без имени",

                touristDetailsPhone:
                    tourist.phone ||
                    "—",

                touristDetailsEmail:
                    tourist.email ||
                    "—",

                touristDetailsCountry:
                    tourist.country ||
                    "—",

                touristDetailsStatus:
                    statusText(
                        status
                    ),

                touristDetailsTour:
                    booking.tourTitle ||
                    "Без названия",

                touristDetailsDate:
                    formatDate(
                        booking.date
                    ),

                touristDetailsCount:
                    travellerCount(
                        booking
                    ),

                touristDetailsBooking:
                    bookingNumber(
                        booking.id
                    )

            };


            Object.entries(
                values
            ).forEach(
                ([elementId, value]) => {

                    const element =
                        document.getElementById(
                            elementId
                        );

                    if (element) {

                        element.textContent =
                            value;
                    }
                }
            );


            // =========================
            // История бронирований туриста
            // =========================

            const selectedIdentity =
                identityKey(booking);

            const history =
                touristBookings
                    .filter(
                        item =>
                            identityKey(item) ===
                            selectedIdentity
                    )
                    .sort(
                        (a, b) => {

                            const aTime =
                                new Date(
                                    a.createdAt ||
                                    0
                                ).getTime() ||
                                Number(a.id) ||
                                0;

                            const bTime =
                                new Date(
                                    b.createdAt ||
                                    0
                                ).getTime() ||
                                Number(b.id) ||
                                0;

                            return bTime - aTime;
                        }
                    );

            const historyContainer =
                document.getElementById(
                    "touristDetailsHistory"
                );

            const tripsCount =
                document.getElementById(
                    "touristDetailsTripsCount"
                );

            if (tripsCount) {
                tripsCount.textContent =
                    history.length;
            }

            if (historyContainer) {

                historyContainer.innerHTML =
                    "";

                history.forEach(
                    item => {

                        const itemStatus =
                            normalizedStatus(
                                item
                            );

                        const historyItem =
                            document.createElement(
                                "div"
                            );

                        historyItem.className =
                            "tourist-history__item";

                        historyItem.innerHTML = `
                            <div class="tourist-history__main">
                                <strong>
                                    ${escapeHtml(
                                        item.tourTitle ||
                                        "Без названия"
                                    )}
                                </strong>

                                <span>
                                    ${escapeHtml(
                                        formatDate(
                                            item.date
                                        )
                                    )}
                                    ·
                                    ${travellerCount(
                                        item
                                    )}
                                    чел.
                                </span>
                            </div>

                            <div class="tourist-history__side">
                                <span
                                    class="tourist-status tourist-status-${itemStatus}">
                                    ${escapeHtml(
                                        statusText(
                                            itemStatus
                                        )
                                    )}
                                </span>

                                <small>
                                    ${escapeHtml(
                                        bookingNumber(
                                            item.id
                                        )
                                    )}
                                </small>
                            </div>
                        `;

                        historyContainer.appendChild(
                            historyItem
                        );
                    }
                );
            }


            modal.hidden =
                false;

            document.body.classList.add(
                "tourist-modal-open"
            );
        }


        function csvCell(value) {

            return (
                '"' +
                String(value ?? "")
                    .replaceAll(
                        '"',
                        '""'
                    ) +
                '"'
            );
        }


        function exportCsv() {

            if (
                touristBookings.length ===
                0
            ) {

                alert(
                    "Нет данных туристов для экспорта."
                );

                return;
            }


            const rows = [

                [
                    "ФИО",
                    "Телефон",
                    "Email",
                    "Страна",
                    "Тур",
                    "Дата тура",
                    "Количество туристов",
                    "Статус",
                    "№ бронирования"
                ],

                ...touristBookings.map(
                    booking => {

                        const tourist =
                            booking.tourist ||
                            {};

                        const status =
                            normalizedStatus(
                                booking
                            );

                        return [
                            tourist.fullName ||
                                "",
                            tourist.phone ||
                                "",
                            tourist.email ||
                                "",
                            tourist.country ||
                                "",
                            booking.tourTitle ||
                                "",
                            booking.date ||
                                "",
                            travellerCount(
                                booking
                            ),
                            statusText(
                                status
                            ),
                            bookingNumber(
                                booking.id
                            )
                        ];
                    }
                )
            ];


            const csv =
                rows
                    .map(
                        row =>
                            row
                                .map(csvCell)
                                .join(";")
                    )
                    .join("\n");


            const blob =
                new Blob(
                    [
                        "\uFEFF",
                        csv
                    ],
                    {
                        type:
                            "text/csv;charset=utf-8"
                    }
                );

            const url =
                URL.createObjectURL(
                    blob
                );

            const link =
                document.createElement(
                    "a"
                );

            link.href =
                url;

            link.download =
                "tourists.csv";

            document.body.appendChild(
                link
            );

            link.click();
            link.remove();

            URL.revokeObjectURL(
                url
            );
        }


        searchInput?.addEventListener(
            "input",
            render
        );


        statusFilter?.addEventListener(
            "change",
            render
        );


        exportButton?.addEventListener(
            "click",
            exportCsv
        );


        tableBody?.addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        "[data-action='view']"
                    );

                if (!button) {
                    return;
                }

                const row =
                    button.closest(
                        "tr[data-id]"
                    );

                if (!row) {
                    return;
                }

                openDetails(
                    row.dataset.id
                );
            }
        );


        document.addEventListener(
            "keydown",
            event => {

                const modal =
                    document.getElementById(
                        "touristDetailsModal"
                    );

                if (
                    event.key ===
                        "Escape" &&
                    modal &&
                    !modal.hidden
                ) {

                    modal.hidden =
                        true;

                    document.body.classList.remove(
                        "tourist-modal-open"
                    );
                }
            }
        );


        window.addEventListener(
            "storage",
            event => {

                if (
                    event.key ===
                    STORAGE_KEY
                ) {

                    readBookings();
                    render();
                }
            }
        );


        readBookings();
        render();

    }
);
