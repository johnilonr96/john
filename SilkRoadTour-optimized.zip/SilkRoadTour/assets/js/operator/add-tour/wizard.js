import TourValidation from "./validation.js";

class TourWizard {

    constructor() {

        this.currentStep = 0;

        this.steps = document.querySelectorAll(".wizard-card");

        this.indicators = document.querySelectorAll(".wizard-step");

        this.prevBtn = document.querySelector(".wizard-navigation .btn-outline");

        this.nextBtn = document.querySelector(".wizard-navigation .btn-primary");

        this.init();

    }

    init() {

        this.update();

        this.prevBtn.addEventListener("click", () => this.prev());

        this.nextBtn.addEventListener("click", () => this.next());

    }

    next() {

        if (!TourValidation.validateStep(this.currentStep)) {

        return;

        }

        if (this.currentStep >= this.steps.length - 1) return;

        this.currentStep++;

        this.update();

    }

    prev() {

        if (this.currentStep <= 0) return;

        this.currentStep--;

        this.update();

    }

    update() {

        this.steps.forEach(step => {

            step.classList.remove("active-step");

            step.classList.add("step-hidden");

        });

        this.steps[this.currentStep].classList.remove("step-hidden");

        this.steps[this.currentStep].classList.add("active-step");

        this.indicators.forEach(indicator => indicator.classList.remove("active"));

        this.indicators[this.currentStep].classList.add("active");

        this.prevBtn.disabled = this.currentStep === 0;

        if (this.currentStep === this.steps.length - 1) {

            this.nextBtn.innerHTML = '<i class="fa-solid fa-check"></i> Опубликовать';

        } else {

            this.nextBtn.innerHTML = 'Далее <i class="fa-solid fa-arrow-right"></i>';

        }

        const publicationContainer =
            document.getElementById("tourPublicationBuilder");

        if (
            publicationContainer &&
            !publicationContainer.classList.contains("step-hidden")
        ) {

            if (window.publicationBuilder) {

                window.publicationBuilder.updatePreview();

            }

        }
        
    }

}

export default TourWizard;