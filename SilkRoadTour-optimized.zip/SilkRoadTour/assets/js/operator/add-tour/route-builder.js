class RouteBuilder {

    constructor() {

        this.routeList =
            document.getElementById("routeList");

        this.addBtn =
            document.getElementById("addCityBtn");

        this.cities =
            window.tourData.route || [];

        window.tourData.route =
            this.cities;
        
        this.init();

    }

    init() {

        if (!this.routeList || !this.addBtn) return;

        this.addBtn.addEventListener("click", () => {

            this.addCity();

        });

    }

    addCity() {

        this.cities.push({

            city: "",

            hotel: "",

            meal: "Не указано",

            transport: "Автобус",

            arrival: "",

            departure: "",

            activities: [],

            collapsed: false

        });

        this.render();

    }

    render() {

        this.routeList.innerHTML = "";

        this.cities.forEach((itemData, index) => {

            const item = document.createElement("div");

            item.className = "route-item";

            item.innerHTML = `

            <div class="route-card">

                <div class="route-day-header">

                    <button
                        type="button"
                        
                        class="toggle-route">

                        ▼

                    </button>

                    <div class="day-badge">

                        День ${index + 1}

                    </div>

                    <h3 class="route-city-title">

                        ${itemData.city || "Новый город"}

                    </h3>

                </div>
            
                <div class="route-header">

                    <div class="route-number">
                        ${index + 1}
                    </div>

                    <input
                        type="text"
                        class="city-input"
                        placeholder="Введите город"
                        value="${itemData.city}"
                    >

                </div>

                <div class="route-details ${itemData.collapsed ? "collapsed" : ""}">

                    <div class="route-field">

                        <label>🏨 Отель</label>

                        <input
                            type="text"
                            class="hotel-input"
                            value="${itemData.hotel}"
                            placeholder="Название отеля">

                    </div>

                    <div class="route-field">

                        <label>🕒 Отправление</label>

                        <input type="time"

                        class="departure-input"

                        value="${itemData.departure}">

                    </div>                    

                    <div class="route-field">

                        <label>🍽 Питание</label>

                        <select class="meal-select">

                            <option ${itemData.meal==="Не указано"?"selected":""}>Не указано</option>
                            <option ${itemData.meal==="Завтрак"?"selected":""}>Завтрак</option>
                            <option ${itemData.meal==="Полупансион"?"selected":""}>Полупансион</option>
                            <option ${itemData.meal==="Полный пансион"?"selected":""}>Полный пансион</option>
                            <option ${itemData.meal==="Всё включено"?"selected":""}>Всё включено</option>

                        </select>

                    </div>

                    <div class="route-field">

                        <label>🕘 Прибытие</label>

                        <input type="time"
                        
                        class="arrival-input"
                        
                        value="${itemData.arrival}">

                    </div>                    

                    <div class="route-field">

                        <label>🚌 Транспорт</label>

                        <select class="transport-select">

                            <option ${itemData.transport==="Автобус"?"selected":""}>Автобус</option>
                            <option ${itemData.transport==="Поезд"?"selected":""}>Поезд</option>
                            <option ${itemData.transport==="Самолёт"?"selected":""}>Самолёт</option>
                            <option ${itemData.transport==="Минивэн"?"selected":""}>Минивэн</option>

                        </select>

                    </div>

                    <div class="activities-section">

                        <h4>
                            📍 Достопримечательности / активности
                        </h4>

                        <div 
                            
                            class="activities-list"

                            data-city="${index}">

                        </div>

                        <button

                            type="button"

                            class="add-activity"

                            data-city="${index}">

                            <i class="fa-solid fa-plus"></i>

                            Добавить достопримечательность

                        </button>

                    </div>

                </div>

                <div class="route-actions">

                    <button type="button"
                            class="move-up"
                            title="Переместить вверх">
                    
                        ▲

                    </button>

                    <button type="button"
                            class="move-down"
                            title="Переместить вниз">

                        ▼

                    </button>

                    <button type="button"
                            class="remove-city"
                            title="Удалить город">

                        🗑

                    </button>

                </div>

            </div>

            `;

            this.routeList.appendChild(item);

            const removeBtn = item.querySelector(".remove-city");

            removeBtn.addEventListener("click", () => {

                this.removeCity(index);

            });
            
            const upBtn = item.querySelector(".move-up");

            upBtn.addEventListener("click", () => {

                this.moveUp(index);

            });

            const downBtn = item.querySelector(".move-down");
            
            /* ------------------------------
            Свернуть / Развернуть
            ------------------------------ */

            const toggleBtn = item.querySelector(".toggle-route");

            toggleBtn.addEventListener("click", () => {

                this.cities[index].collapsed = !this.cities[index].collapsed;

                this.render();

            });

            /* ------------------------------
            Добавить достопримечательность
            ------------------------------ */

            const addActivityBtn = item.querySelector(".add-activity");

            addActivityBtn.addEventListener("click", () => {

                this.addActivity(index);

            });

            /* ------------------------------
            Отрисовка достопримечательностей
            ------------------------------ */

            const activitiesContainer = item.querySelector(".activities-list");

            this.renderActivities(index, activitiesContainer);
            
            const cityInput = item.querySelector(".city-input");

            const cityTitle = item.querySelector(".route-city-title");

            cityInput.addEventListener("input", (e) => {

                this.cities[index].city = e.target.value;

                window.saveTourData();

                console.log("Маршрут:", window.tourData.route);

                cityTitle.textContent = e.target.value || "Новый город";

            });
            
            /* ------------------------------
            Отель
            ------------------------------ */

            const hotelInput = item.querySelector(".hotel-input");

            hotelInput.addEventListener("input", (e) => {

                this.cities[index].hotel = e.target.value;

                window.saveTourData();

                console.log("Отель:", window.tourData.route[index].hotel);

            });

            /* ------------------------------
            Питание
            ------------------------------ */

            const mealSelect = item.querySelector(".meal-select");

            mealSelect.addEventListener("change", (e) => {

                this.cities[index].meal = e.target.value;

                window.saveTourData();

                console.log("Питание:", window.tourData.route[index].meal);

            });

            /* ------------------------------
            Транспорт
            ------------------------------ */

            const transportSelect = item.querySelector(".transport-select");

            transportSelect.addEventListener("change", (e) => {

                this.cities[index].transport = e.target.value;

                window.saveTourData();

                console.log("Транспорт:", window.tourData.route[index].transport);

            });

            /* ------------------------------
            Прибытие
            ------------------------------ */

            const arrivalInput = item.querySelector(".arrival-input");

            arrivalInput.addEventListener("input", (e) => {

                this.cities[index].arrival = e.target.value;

                window.saveTourData();

                console.log("Прибытие:", window.tourData.route[index].arrival);

            });

            /* ------------------------------
            Отправление
            ------------------------------ */

            const departureInput = item.querySelector(".departure-input");

            departureInput.addEventListener("input", (e) => {

                this.cities[index].departure = e.target.value;

                window.saveTourData();

                console.log("Отправление:", window.tourData.route[index].departure);

            });

            downBtn.addEventListener("click", () => {

                this.moveDown(index);

            });

        });

    }

    removeCity(index) {

        this.cities.splice(index, 1);

        window.saveTourData();

        this.render();

    }

    moveUp(index) {

        if (index === 0) return;

        [this.cities[index], this.cities[index - 1]] =
        [this.cities[index - 1], this.cities[index]];

        window.saveTourData();

        this.render();

    }

    moveDown(index) {

        if (index === this.cities.length - 1) return;

        [this.cities[index], this.cities[index + 1]] =
        [this.cities[index + 1], this.cities[index]];

        window.saveTourData();

        this.render();

    }

    addActivity(cityIndex) {

        this.cities[cityIndex].activities.push({

            title: "",

            duration: "",

            description: "",

            image: "",

            price: "",

            included: true

        });

        window.saveTourData();

        this.render();

    }

    renderActivities(cityIndex, container) {

        container.innerHTML = "";

        this.cities[cityIndex].activities.forEach((activity, activityIndex) => {

            const card = document.createElement("div");

            card.className = "activity-card";

            card.innerHTML = `

            <div class="activity-card">

                <div class="activity-header">

                    <h5>

                        🏛 Достопримечательность ${activityIndex + 1}

                    </h5>

                    <button
                        type="button"
                        class="remove-activity"
                        title="Удалить достопримечательность">

                        🗑

                    </button>

                </div>

                <div class="activity-content">

                    <!-- Левая колонка -->

                    <div class="activity-left">

                        <div class="activity-field">

                            <label>Название</label>

                            <input
                                type="text"
                                class="activity-title"
                                value="${activity.title}"
                                placeholder="Например: Регистан">

                        </div>

                        <div class="activity-field">

                            <label>Продолжительность</label>

                            <input
                                type="text"
                                class="activity-duration"
                                value="${activity.duration}"
                                placeholder="2 часа">

                        </div>

                        <div class="activity-field">

                            <label>Описание</label>

                            <textarea
                                class="activity-description"
                                rows="5"
                                placeholder="Описание объекта">${activity.description}</textarea>

                        </div>

                    </div>

                    <!-- Правая колонка -->

                    <div class="activity-right">

                        <div class="activity-field">

                            <label>Фото</label>

                            <input
                                type="file"
                                class="activity-image"
                                accept="image/*">

                        </div>

                        <div class="activity-preview">

                            ${
                                activity.image
                                ? `
                                    <img
                                        src="${activity.image}"
                                        class="preview-image"
                                        alt="preview">
                                `
                                : `
                                    <div class="empty-preview">

                                        <i class="fa-regular fa-image"></i>

                                        <span>Нет изображения</span>

                                    </div>
                                `
                            }

                        </div>

                        <button
                            type="button"
                            class="remove-image"
                            data-city="${cityIndex}"
                            data-activity="${activityIndex}">

                            <i class="fa-solid fa-trash"></i>

                            Удалить фото

                        </button>

                    </div>

                </div>

            </div>

            `;

            container.appendChild(card);

            /* ------------------------------
            Название
            ------------------------------ */

            const titleInput = card.querySelector(".activity-title");

            titleInput.addEventListener("input", (e) => {

                this.cities[cityIndex].activities[activityIndex].title = 
                    e.target.value;

                window.saveTourData();

                console.log("Достопримечательность:", window.tourData.route[cityIndex]
                    .activities[activityIndex].title);
            
            });

            /* ------------------------------
            Продолжительность
            ------------------------------ */

            const durationInput = card.querySelector(".activity-duration");

            durationInput.addEventListener("input", (e) => {

                this.cities[cityIndex].activities[activityIndex].duration = e.target.value;

                window.saveTourData();

                console.log("Продолжительность:", window.tourData.route[cityIndex]
                    .activities[activityIndex].duration);
            });

            /* ------------------------------
            Описание
            ------------------------------ */

            const descriptionInput = card.querySelector(".activity-description");

            descriptionInput.addEventListener("input", (e) => {

                this.cities[cityIndex].activities[activityIndex].description = e.target.value;

                window.saveTourData();

                console.log("Описание:", window.tourData.route[cityIndex]
                    .activities[activityIndex].description);
            });

            /* ------------------------------
            Фото
            ------------------------------ */

            const imageInput = card.querySelector(".activity-image");

            imageInput.addEventListener("change", (e) => {

                const file = e.target.files[0];

                if (!file) return;

                const reader = new FileReader();

                reader.onload = (event) => {

                    this.cities[cityIndex].activities[activityIndex]
                        .image = event.target.result;

                    window.saveTourData();

                    console.log(
                        "Фото достопримечательности:",
                        window.tourData.route[cityIndex].activities[activityIndex]
                            .image
                    );

                    this.render();

                };

                reader.readAsDataURL(file);

            });

            /* ------------------------------
            Удалить фото
            ------------------------------ */

            const removeImageBtn = card.querySelector(".remove-image");

            removeImageBtn.addEventListener("click", () => {

                this.cities[cityIndex].activities[activityIndex].image = "";

                window.saveTourData();

                this.render();

            });

            /* ------------------------------
            Удалить достопримечательность
            ------------------------------ */

            const removeActivityBtn = card.querySelector(".remove-activity");

            removeActivityBtn.addEventListener("click", () => {

                this.cities[cityIndex].activities.splice(activityIndex, 1);

                window.saveTourData();

                this.render();

            });

        });

    }
    
    /*removeActivity(cityIndex, activityIndex) {

        this.cities[cityIndex].activities.splice(activityIndex, 1);

        this.render();

    }*/

}

export default RouteBuilder;