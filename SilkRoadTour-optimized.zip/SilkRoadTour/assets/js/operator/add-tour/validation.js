class TourValidation {

    static validateStep(stepIndex) {

        switch (stepIndex) {

            case 0:
                return this.validateGeneral();

            case 1:
                return this.validateRoute();

            case 2:
                return this.validateProgram();

            case 3:
                return this.validatePrice();

            case 4:
                return this.validateGallery();

            default:
                return true;

        }

    }

    static validateGeneral() {

        console.log("validateGeneral");

        const inputs = document.querySelectorAll(".active-step [required]");

        let valid = true;

        inputs.forEach(input => {

            if (input.value.trim() === "") {

                input.classList.add("input-error");

                valid = false;

            } else {

                input.classList.remove("input-error");

            }

        });

        if (!valid) {

            alert("Пожалуйста, заполните обязательные поля.");

        }

        console.log(valid);
        
        return valid;

    }

    static validateRoute() {

        return true;

    }

    static validateProgram() {

        return true;

    }

    static validatePrice() {

        return true;

    }

    static validateGallery() {

        return true;

    }

}

export default TourValidation;