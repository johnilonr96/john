class GalleryBuilder {

    constructor(){

        this.container =
            document.getElementById("tourGalleryBuilder");

        this.data = window.tourData;

        this.render();

    }

    render() {

        this.container.innerHTML = `

            <div class="gallery-step">

                <p>

                    Добавьте фотографии тура

                </p>

                <div class="gallery-upload">

                    <div class="gallery-icon">

                        📷

                    </div>

                    <div class="gallery-text">

                        Перетащите фотографии сюда

                    </div>

                    <div class="gallery-or">

                        или

                    </div>

                    <button class="gallery-button">

                        Выбрать изображения

                    </button>

                    <input
                        type="file"
                        class="gallery-input"
                        multiple
                        accept="image/*"
                        hidden>

                </div>

                <div class="gallery-preview">
                
                </div>

            </div>

        `;

        /* -------------------------
        Превью изображений
        ------------------------- */

        const preview =
        this.container.querySelector(".gallery-preview");

        this.data.gallery.forEach((photo, index) => {

            const card = document.createElement("div");

            card.className = "gallery-card";

            if (photo.isMain) {

                card.classList.add("main-photo-active");

            }

            card.innerHTML = `

                <img
                    src="${photo.image}"
                    class="gallery-image">

                <div class="gallery-actions">

                    <button
                        type="button"
                        class="main-photo">

                        ${photo.isMain ? "⭐ Главная" : "☆ Сделать главной"}

                    </button>

                    <button
                        type="button"
                        class="delete-photo">

                        🗑

                    </button>

                </div>

            `;

            preview.appendChild(card);


            /* -------------------------
            Выбор главной фотографии
            ------------------------- */

            const mainButton =
                card.querySelector(".main-photo");

            mainButton.addEventListener("click", (e) => {

                e.preventDefault();

                this.data.gallery.forEach(item => {

                    item.isMain = false;

                });

                this.data.gallery[index].isMain = true;

                window.saveTourData();

                this.render();

            });

            const deleteButton =
                card.querySelector(".delete-photo");

            deleteButton.addEventListener("click", (e) => {

                e.preventDefault();

                this.data.gallery.splice(index, 1);

                window.saveTourData();

                this.render();

            });

        });

        /* -------------------------
        Кнопка выбора изображений
        ------------------------- */

        const button =
        this.container.querySelector(".gallery-button");

        const input =
        this.container.querySelector(".gallery-input");

        button.addEventListener("click", () => {

            input.click();

        });

        /* -------------------------
        Выбор файлов
        ------------------------- */

        input.addEventListener("change", (e) => {

            const files = Array.from(e.target.files);

            files.forEach(file => {

                const reader = new FileReader();

                reader.onload = (event) => {

                    this.data.gallery.push({

                        image: event.target.result,

                        isMain: false

                    });

                    window.saveTourData();

                    console.log(this.data.gallery);

                    this.render();

                };

                reader.readAsDataURL(file);

            });

        });

    }

}

export default GalleryBuilder;