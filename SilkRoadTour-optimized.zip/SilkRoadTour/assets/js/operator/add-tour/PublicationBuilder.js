class PublicationBuilder {

    constructor() {

        this.container =
            document.getElementById("tourPublicationBuilder");

        this.data = 
            window.tourData.publication || {
                status: "draft",
                publishDate: "",
                publishTime: "",
                confirmed: false
            };

        window.tourData.publication = this.data;

        this.render();

        this.initPublicationControls();

        this.updatePreview();

    }

    render() {

        this.container.innerHTML = `

            <div class="publication-step">

                <div class="publication-summary">

                    <h4>📋 Предпросмотр тура</h4>

                    <div class="preview-grid">

                        <div class="preview-card">

                            <span>🏝 Название тура</span>

                            <strong class="preview-title">—</strong>

                        </div>

                        <div class="preview-card">

                            <span>🌍 Направление</span>

                            <strong class="preview-country">—</strong>

                        </div>

                        <div class="preview-card">

                            <span>📍 Маршрут</span>

                            <strong class="preview-route">—</strong>

                        </div>

                        <div class="preview-card">

                            <span>📅 Продолжительность</span>

                            <strong class="preview-days">0 дней</strong>

                        </div>

                        <div class="preview-card">

                            <span>👤 Цена взрослого</span>

                            <strong class="preview-adult">0</strong>

                        </div>

                        <div class="preview-card">

                            <span>🧒 Цена ребёнка</span>

                            <strong class="preview-child">0</strong>

                        </div>
                        
                        <div class="preview-card">

                            <span>➕ Дополнительные услуги</span>

                            <strong class="preview-services">0</strong>

                        </div>

                        <div class="preview-card">

                            <span>💵 Общая стоимость</span>

                            <strong class="preview-total-value">0</strong>

                        </div>

                        <div class="preview-card">

                            <span>📷 Фотографий</span>

                            <strong class="preview-gallery">0</strong>

                        </div>

                        <div class="preview-card">

                            <span>⭐ Главная фотография</span>

                            <strong class="preview-main-photo">Нет</strong>

                        </div>

                    </div>

                </div>

                <div class="publication-status">

                    <h4>Статус публикации</h4>

                    <label>

                        <input
                            type="radio"
                            name="publishStatus"
                            value="draft"
                            checked>

                        📝 Черновик

                    </label>

                    <label>

                        <input
                            type="radio"
                            name="publishStatus"
                            value="publish">

                        🌍 Опубликовать сразу

                    </label>

                    <label>

                        <input
                            type="radio"
                            name="publishStatus"
                            value="schedule">

                        📅 Запланировать публикацию

                    </label>

                </div>

                <div class="schedule-block" style="display:none;">

                    <input
                        type="date"
                        class="publish-date">

                    <input
                        type="time"
                        class="publish-time">

                </div>

                <div class="confirm-block">

                    <label>

                        <input
                            type="checkbox"
                            class="confirm-checkbox">

                        ✔ Я проверил всю информацию

                    </label>

                </div>

                <button
                    class="publish-button"
                    disabled>

                    🚀 Опубликовать

                </button>

            </div>

        `;

    }

    initPublicationControls() {

        const statusInputs =
            this.container.querySelectorAll(
                'input[name="publishStatus"]'
            );

        const scheduleBlock =
            this.container.querySelector(".schedule-block");

        const confirmCheckbox =
            this.container.querySelector(".confirm-checkbox");

        const publishButton =
            this.container.querySelector(".publish-button");

        const publishDate =
            this.container.querySelector(".publish-date");

        const publishTime =
            this.container.querySelector(".publish-time");

        /* -------------------------
        Проверка возможности публикации
        ------------------------- */
        const updatePublishButton = () => {

            const selectedStatus =
                this.container.querySelector(
                    'input[name="publishStatus"]:checked'
                )?.value;

            const confirmed =
                confirmCheckbox.checked;

            let canPublish =
                confirmed;

            /* Для запланированной публикации
            нужны дата и время */
            if (selectedStatus === "schedule") {

                canPublish =
                    confirmed &&
                    publishDate.value &&
                    publishTime.value;

            }

            publishButton.disabled =
                !canPublish;

        };

        /* -------------------------
        Выбор статуса
        ------------------------- */
        statusInputs.forEach(input => {

            input.addEventListener("change", () => {

                const selectedStatus =
                    this.container.querySelector(
                        'input[name="publishStatus"]:checked'
                    )?.value;


                if (selectedStatus === "schedule") {

                    scheduleBlock.style.display =
                        "flex";

                } else {

                    scheduleBlock.style.display =
                        "none";

                }


                this.data.status = selectedStatus;

                window.saveTourData();

                updatePublishButton();

            });

        });

        /* -------------------------
        Подтверждение информации
        ------------------------- */
        confirmCheckbox.addEventListener(
            "change",
            () => {

                this.data.confirmed =
                    confirmCheckbox.checked;

                window.saveTourData();

                updatePublishButton();

            }
        );

        /* -------------------------
        Дата и время
        ------------------------- */
        publishDate.addEventListener(
            "change",
            () => {

                this.data.publishDate =
                    publishDate.value;

                window.saveTourData();
                
                updatePublishButton();

            }
        );

        publishTime.addEventListener(
            "change",
            () => {

                this.data.publishTime =
                    publishTime.value;

                window.saveTourData();

                updatePublishButton();

            }
        );

        /* -------------------------
        Кнопка публикации
        ------------------------- */
        publishButton.addEventListener(
            "click",
            () => {

                if (publishButton.disabled) {
                    return;
                }

                // Получаем весь текущий тур
                const tourToPublish = {
                    ...window.tourData,

                    publication: {
                        ...window.tourData.publication,

                        status: "published"
                    }
                };

                // Получаем уже опубликованные туры
                const publishedTours =
                    JSON.parse(
                        localStorage.getItem("publishedTours")
                    ) || [];

                // Добавляем текущий тур
                //publishedTours.push(tourToPublish);

                // Проверяем, редактируем ли мы существующий тур
                const editingIndex =
                    localStorage.getItem(
                        "editingPublishedTourIndex"
                    );

                if (editingIndex !== null) {

                    const index =
                        Number(editingIndex);

                    if (
                        Number.isInteger(index) &&
                        index >= 0 &&
                        index < publishedTours.length
                    ) {

                        // Обновляем существующий тур
                        publishedTours[index] =
                            tourToPublish;

                        console.log(
                            "✅ Тур обновлён:",
                            tourToPublish
                        );

                    } else {

                        console.error(
                            "❌ Не удалось найти редактируемый тур"
                        );

                        return;
                    }

                } else {

                    // Это новый тур
                    publishedTours.push(
                        tourToPublish
                    );

                    console.log(
                        "✅ Новый тур опубликован:",
                        tourToPublish
                    );

                }

                // Сохраняем список опубликованных туров
                localStorage.setItem(
                    "publishedTours",
                    JSON.stringify(publishedTours)
                );

                // Режим редактирования больше не нужен
                //localStorage.removeItem(
                //    "editingPublishedTourIndex"
                //);

                // Обновляем текущий tourData
                //window.tourData =
                //    tourToPublish;

                // Сохраняем текущий tourData
                //window.saveTourData();
                
                // Опубликованный тур уже сохранён в publishedTours,
                // поэтому очищаем текущий черновик
                localStorage.removeItem("tourData");

                // Выходим из режима редактирования
                localStorage.removeItem(
                    "editingPublishedTourIndex"
                );

                // Переходим в раздел "Мои туры"
                window.location.href =
                    "tours.html";

                console.log(
                    "Тур опубликован:",
                    tourToPublish
                );

                console.log(
                    "Все опубликованные туры:",
                    publishedTours
                );

                // Переходим в раздел "Мои туры"
                window.location.href =
                    "tours.html";

            }
        );

        /* Начальное состояние */
        updatePublishButton();

    }

    updatePreview() {

        // =========================
        // Название тура
        // =========================

        const titlePreview =
            this.container.querySelector(".preview-title");

        if (titlePreview) {

            titlePreview.textContent =
                window.tourData.basic?.title?.trim() || "—";

        }

        // =========================
        // Направление
        // =========================

        const directionPreview =
            this.container.querySelector(".preview-country");

        if (directionPreview) {

            directionPreview.textContent =
                window.tourData.basic?.direction || "—";

        }
        // =========================
        // Маршрут
        // =========================

        const routePreview =
            this.container.querySelector(".preview-route");

        if (routePreview) {

            const route =
                window.tourData.route || [];

            const cities =
                route
                    .map(item => item.city)
                    .filter(city => city && city.trim());

            routePreview.textContent =
                cities.length
                    ? cities.join(" → ")
                    : "—";

        }

        // =========================
        // Продолжительность
        // =========================

        const durationPreview =
            this.container.querySelector(".preview-days");

        if (durationPreview) {

            const days =
                Number(window.tourData.basic?.duration) || 0;

            durationPreview.textContent =
                days > 0
                    ? `${days} дней`
                    : "0 дней";
        }

        // Цена взрослого
        const adultInput =
            document.querySelector(".adult-price");

        const adultPreview =
            this.container.querySelector(".preview-adult");

        if (adultInput && adultPreview) {

            const adult =
                Number(adultInput.value) || 0;

            const currency =
                document.querySelector(".currency")?.value || "";

            adultPreview.textContent =
                `${adult} ${currency}`;

        }

        // Цена ребёнка
        const childInput =
            document.querySelector(".child-price");

        const childPreview =
            this.container.querySelector(".preview-child");

        if (childInput && childPreview) {

            const child =
                Number(childInput.value) || 0;

            const currency =
                document.querySelector(".currency")?.value || "";

            childPreview.textContent =
                `${child} ${currency}`;

        }
        
        // Дополнительные услуги
        const servicePrices =
            document.querySelectorAll(".service-price");

        const servicesPreview =
            this.container.querySelector(".preview-services");

        if (servicesPreview) {

            let servicesTotal = 0;

            servicePrices.forEach(input => {

                servicesTotal +=
                    Number(input.value) || 0;

            });

            const currency =
                document.querySelector(".currency")?.value || "";

            servicesPreview.textContent =
                `${servicesTotal} ${currency}`;

        }

        // Общая стоимость

        const totalPreview =
            this.container.querySelector(".preview-total-value");

        if (totalPreview) {

            const adult =
                Number(
                    document.querySelector(".adult-price")?.value
                ) || 0;

            const child =
                Number(
                    document.querySelector(".child-price")?.value
                ) || 0;

            const serviceInputs =
                document.querySelectorAll(".service-price");

            let servicesTotal = 0;

            serviceInputs.forEach(input => {

                servicesTotal +=
                    Number(input.value) || 0;

            });

            const currency =
                document.querySelector(".currency")?.value || "";

            const total =
                adult + child + servicesTotal;

            totalPreview.textContent =
                `${total} ${currency}`;

        }

        // Количество фотографий
        const galleryImages =
            document.querySelectorAll(".gallery-image");

        const galleryPreview =
            this.container.querySelector(".preview-gallery");

        if (galleryPreview) {

            galleryPreview.textContent =
                `${galleryImages.length}`;

        }

        // Главная фотография
        const galleryCards =
            document.querySelectorAll(".gallery-card");

        const mainPhotoPreview =
            this.container.querySelector(".preview-main-photo");

        if (mainPhotoPreview) {

            let mainPhoto = null;

            galleryCards.forEach(card => {

                if (card.classList.contains("main-photo-active")) {

                    mainPhoto =
                        card.querySelector(".gallery-image");

                }

            });

            if (mainPhoto) {

                mainPhotoPreview.innerHTML = `

                    <img
                        src="${mainPhoto.src}"
                        class="publication-main-image">

                `;

            } else {

                mainPhotoPreview.textContent =
                    "Главная фотография не выбрана";

            }

        }

        /* -------------------------
        Кнопка публикации
        ------------------------- */
        const publishButton =
            this.container.querySelector(".publish-button");

        publishButton.addEventListener("click", () => {

            console.log("Кнопка публикации нажата");

            console.log("Данные тура:", this.data);

        });

    }

}

export default PublicationBuilder;