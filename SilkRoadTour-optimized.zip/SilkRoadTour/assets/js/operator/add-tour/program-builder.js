class ProgramBuilder {

    constructor() {

        this.container =
            document.getElementById("programBuilder");

        this.addDayBtn =
            document.getElementById("addDayBtn");

        this.days =
            window.tourData.program || [];

        window.tourData.program =
            this.days;
        
        this.init();

    }

    init() {

        if (!this.container || !this.addDayBtn) return;

        this.addDayBtn.addEventListener("click", () => {

            this.addDay();

        });

    }

    addDay() {

        this.days.push({

            events: []

        });

        window.saveTourData();

        this.render();

    }

    render() {

        this.container.innerHTML = "";

        this.days.forEach((day, dayIndex) => {

            const card = document.createElement("div");

            card.className = "program-day-card";

            card.innerHTML = `

        <div class="program-day-header">

            <div class="day-title">

                <i class="fa-regular fa-calendar-days"></i>

                <span>День ${dayIndex + 1}</span>

            </div>

            <div class="day-actions">

                <button class="move-day-up" title="Переместить вверх">

                    ↑

                </button>

                <button class="move-day-down" title="Переместить вниз">

                    ↓

                </button>

                <button class="remove-day" title="Удалить день">

                    🗑

                </button>

            </div>

        </div>

                <div class="events-list"></div>

                <button class="add-event">

                    ➕ Добавить событие

                </button>

            `;

            this.container.appendChild(card);

            const eventsContainer =
                card.querySelector(".events-list");

            day.events.forEach((event, eventIndex) => {

                const row = document.createElement("div");

                row.className = "event-row";

                row.innerHTML = `

                    <input
                        type="time"
                        class="event-time"
                        value="${event.time}">

                    <select class="event-type">

                        <option value="Трансфер" ${event.type==="Трансфер"?"selected":""}>
                            🚗 Трансфер
                        </option>

                        <option value="Экскурсия" ${event.type==="Экскурсия"?"selected":""}>
                            🏛 Экскурсия
                        </option>

                        <option value="Питание" ${event.type==="Питание"?"selected":""}>
                            🍽 Питание
                        </option>

                        <option value="Заселение" ${event.type==="Заселение"?"selected":""}>
                            🏨 Заселение
                        </option>

                        <option value="Свободное время" ${event.type==="Свободное время"?"selected":""}>
                            🎭 Свободное время
                        </option>

                        <option value="Шопинг" ${event.type==="Шопинг"?"selected":""}>
                            🛍 Шопинг
                        </option>

                        <option value="Прогулка" ${event.type==="Прогулка"?"selected":""}>
                            🚶 Прогулка
                        </option>

                        <option value="Другое" ${event.type==="Другое"?"selected":""}>
                            📍 Другое
                        </option>

                    </select>

                    <input
                        type="text"
                        class="event-location"
                        placeholder="Место"
                        value="${event.location}">

                    <input
                        type="text"
                        class="event-title"
                        placeholder="Описание события"
                        value="${event.title}">

                    <div class="event-actions">

                        <button
                            type="button"
                            class="move-event-up"
                            title="Поднять">

                            ↑

                        </button>

                        <button
                            type="button"
                            class="move-event-down"
                            title="Опустить">

                            ↓

                        </button>

                        <button
                            type="button"
                            class="remove-event"
                            title="Удалить">

                            🗑

                        </button>

                    </div>

                `;

                eventsContainer.appendChild(row);
                
                /* ------------------------------
                Удалить событие
                ------------------------------ */

                const removeEventBtn = row.querySelector(".remove-event");

                removeEventBtn.addEventListener("click", () => {

                    this.removeEvent(dayIndex, eventIndex);

                });

                /* ------------------------------
                Поднять событие
                ------------------------------ */

                const upBtn = row.querySelector(".move-event-up");

                upBtn.addEventListener("click", () => {

                    this.moveEventUp(dayIndex, eventIndex);

                });

                /* ------------------------------
                Опустить событие
                ------------------------------ */

                const downBtn = row.querySelector(".move-event-down");

                downBtn.addEventListener("click", () => {

                    this.moveEventDown(dayIndex, eventIndex);

                });

                /* Время */

                row.querySelector(".event-time").addEventListener("input", (e) => {

                    this.days[dayIndex].events[eventIndex].time = e.target.value;
                    
                    window.saveTourData();

                    console.log(
                        "Время события:",
                        window.tourData.program[dayIndex]
                            .events[eventIndex]
                            .time
                    );
                });

                /* Тип */

                row.querySelector(".event-type").addEventListener("change", (e) => {

                    this.days[dayIndex].events[eventIndex].type = e.target.value;
                    
                    window.saveTourData();
                    
                    console.log(
                        "Тип события:",
                        window.tourData.program[dayIndex]
                            .events[eventIndex]
                            .type
                    );
                });

                /* Место */

                row.querySelector(".event-location").addEventListener("input", (e) => {

                    this.days[dayIndex].events[eventIndex].location = e.target.value;
                    
                    window.saveTourData();

                    console.log(
                        "Место события:",
                        window.tourData.program[dayIndex]
                            .events[eventIndex]
                            .location
                    );
                });

                /* Описание */

                row.querySelector(".event-title").addEventListener("input", (e) => {

                    this.days[dayIndex].events[eventIndex].title = e.target.value;
                    
                    window.saveTourData();
                    
                    console.log(
                        "Описание события:",
                        window.tourData.program[dayIndex]
                            .events[eventIndex]
                            .title
                    );
                });
               
            });

            card.querySelector(".add-event")

                .addEventListener("click", () => {

                    this.addEvent(dayIndex);

                });

            card.querySelector(".remove-day")

                .addEventListener("click", () => {

                    this.removeDay(dayIndex);

                });

            card.querySelector(".move-day-up")

                .addEventListener("click", () => {

                    this.moveDayUp(dayIndex);

                });

            card.querySelector(".move-day-down")

                .addEventListener("click", () => {

                    this.moveDayDown(dayIndex);

                });

        });

    }

    addEvent(dayIndex) {

        this.days[dayIndex].events.push({

            time: "",

            type: "Трансфер",

            location:"",

            title: ""

        });

        window.saveTourData();

        this.render();

    }

    removeDay(index) {

        this.days.splice(index,1);

        window.saveTourData();

        this.render();

    }

    /* ----------------------------------
    Перемещение дней
    ---------------------------------- */

    moveDayUp(index) {

        if (index === 0) return;

        [this.days[index], this.days[index - 1]] =
        [this.days[index - 1], this.days[index]];

        window.saveTourData();

        this.render();

    }

    moveDayDown(index) {

        if (index === this.days.length - 1) return;

        [this.days[index], this.days[index + 1]] =
        [this.days[index + 1], this.days[index]];

        window.saveTourData();

        this.render();

    }

    removeEvent(dayIndex, eventIndex) {

        this.days[dayIndex].events.splice(eventIndex, 1);

        window.saveTourData();

        this.render();

    }

    moveEventUp(dayIndex, eventIndex) {

        if (eventIndex === 0) return;

        this.saveCurrentValues();

        const events = this.days[dayIndex].events;

        [events[eventIndex], events[eventIndex - 1]] =
        [events[eventIndex - 1], events[eventIndex]];

        window.saveTourData();

        this.render();

    }

    moveEventDown(dayIndex, eventIndex) {

        const events = this.days[dayIndex].events;

        if (eventIndex === events.length - 1) return;

        this.saveCurrentValues();

        [events[eventIndex], events[eventIndex + 1]] =
        [events[eventIndex + 1], events[eventIndex]];

        window.saveTourData();

        this.render();

    }

    saveCurrentValues() {

        const rows = this.container.querySelectorAll(".event-row");

        rows.forEach((row, index) => {

            const dayCard = row.closest(".program-day-card");

            const dayIndex = [...this.container.children].indexOf(dayCard);

            if (dayIndex === -1) return;

            const event = this.days[dayIndex].events[index];

            if (!event) return;

            event.time = row.querySelector(".event-time").value;

            event.type = row.querySelector(".event-type").value;

            event.location = row.querySelector(".event-location").value;

            event.title = row.querySelector(".event-title").value;

        });

    }
    
}

export default ProgramBuilder;