class PriceBuilder{

    constructor() {

        this.container =
            document.getElementById(
                "tourPriceBuilder"
            );


        if (!this.container) {

            console.error(
                "Не найден #tourPriceBuilder"
            );

            return;

        }


        const savedPrice =
            window.tourData.price || {};


        this.data = {

            currency:
                savedPrice.currency ||
                "USD",

            adult:
                Number(
                    savedPrice.adult
                ) || 0,

            child:
                Number(
                    savedPrice.child
                ) || 0,

            prepayment:
                Number(
                    savedPrice.prepayment
                ) || 0,

            included:
                Array.isArray(
                    savedPrice.included
                )
                    ? savedPrice.included
                    : [],

            services:
                Array.isArray(
                    savedPrice.services
                )
                    ? savedPrice.services
                    : []

        };

        window.tourData.price =
            this.data;

        window.saveTourData();

        this.render();

    }

    render(){

        this.container.innerHTML=`

        <div class="price-card">

            <h2>

                💰 Стоимость тура

            </h2>

            <div class="price-grid">

                <div>

                    <label>Валюта</label>

                    <select class="currency">

                        <option>USD</option>

                        <option>EUR</option>

                        <option>UZS</option>

                    </select>

                </div>

                <div>

                    <label>Цена взрослого</label>

                    <input
                        type="number"
                        class="adult-price">

                </div>

                <div>

                    <label>Цена ребёнка</label>

                    <input
                        type="number"
                        class="child-price">

                </div>

                <div>

                    <label>Предоплата %</label>

                    <input
                        type="number"
                        class="prepayment">

                </div>

            </div>

            <div class="included-block">

                <h3>

                    Что входит в стоимость

                </h3>

                <div class="included-list">

                    <label><input type="checkbox" value="Проживание"> Проживание</label>

                    <label><input type="checkbox" value="Питание"> Питание</label>

                    <label><input type="checkbox" value="Транспорт"> Транспорт</label>

                    <label><input type="checkbox" value="Экскурсии"> Экскурсии</label>

                    <label><input type="checkbox" value="Гид"> Гид</label>

                    <label><input type="checkbox" value="Страховка"> Страховка</label>

                    <label><input type="checkbox" value="Авиабилеты"> Авиабилеты</label>

                    <label><input type="checkbox" value="Виза"> Виза</label>

                </div>

            </div>

            <div class="services-block">

                <h3>

                    Дополнительные услуги

                </h3>

                <button class="add-service">

                    ➕ Добавить услугу

                </button>

                <div class="services-list">

                </div>

            </div>

            <div class="price-summary">

                <h3>
                    💰 Итоговая стоимость
                </h3>

                <div class="summary-item">

                    <div class="summary-title">
                        👤 Взрослый
                    </div>

                    <div class="summary-value summary-adult">

                        ${this.data.adult} ${this.data.currency}

                    </div>

                </div>

                <div class="summary-item">

                    <div class="summary-title">
                        🧒 Ребёнок
                    </div>

                    <div class="summary-value summary-child">

                        ${this.data.child} ${this.data.currency}

                    </div>

                </div>

                <div class="summary-item">

                    <div class="summary-title">
                        ➕ Дополнительные услуги
                    </div>

                    <div class="summary-value summary-services">

                        ${this.getServicesTotal()} ${this.data.currency}

                    </div>

                </div>

                <hr>

                <div class="summary-total">

                    <div class="summary-total-row">

                        <span>

                            💵 Итого взрослый

                        </span>

                        <span class="summary-total-adult">

                            ${this.getTotalAdult()} ${this.data.currency}

                        </span>

                    </div>

                    <div class="summary-total-row">

                        <span>

                            🧒 Итого ребёнок

                        </span>

                        <span class="summary-total-child">

                            ${this.getTotalChild()} ${this.data.currency}

                        </span>

                    </div>

                </div>

            </div>

        </div>

        `;

        /* -------------------------
        Что входит в стоимость
        ------------------------- */

        const includedCheckboxes =
            this.container.querySelectorAll(
                ".included-list input[type='checkbox']"
            );

        includedCheckboxes.forEach((checkbox) => {

            checkbox.checked =
                this.data.included.includes(checkbox.value);

            checkbox.addEventListener("change", () => {

                if (checkbox.checked) {

                    if (!this.data.included.includes(checkbox.value)) {

                        this.data.included.push(checkbox.value);

                    }

                } else {

                    this.data.included =
                        this.data.included.filter(
                            item => item !== checkbox.value
                        );

                }

                window.saveTourData();

                console.log(
                    "Что входит в стоимость:",
                    window.tourData.price.included
                );

            });

        });

        /* -------------------------
        Валюта
        ------------------------- */

        const currency = this.container.querySelector(".currency");

        currency.value = this.data.currency;

        currency.addEventListener("change",(e)=>{

            this.data.currency = e.target.value;

            window.saveTourData();

            console.log(
                "Валюта:",
                window.tourData.price.currency
            );
            
            this.updateSummary();

        });

        /* -------------------------
        Цена взрослого
        ------------------------- */

        const adult = this.container.querySelector(".adult-price");

        adult.value = this.data.adult;

        adult.addEventListener("input",(e)=>{

            this.data.adult = Number(e.target.value);

            window.saveTourData();

            console.log(
                "Цена взрослого:",
                window.tourData.price.adult
            );
         
            this.updateSummary();

        });

        /* -------------------------
        Цена ребёнка
        ------------------------- */

        const child = this.container.querySelector(".child-price");

        child.value = this.data.child;

        child.addEventListener("input",(e)=>{

            this.data.child = Number(e.target.value);

            window.saveTourData();

            console.log(
                "Цена ребёнка:",
                window.tourData.price.child
            );

            this.updateSummary();

        });

        /* -------------------------
        Предоплата
        ------------------------- */

        const prepayment = this.container.querySelector(".prepayment");

        prepayment.value = this.data.prepayment;

        prepayment.addEventListener("input",(e)=>{

            this.data.prepayment = Number(e.target.value);

            window.saveTourData();
            
            console.log(
                "Предоплата:",
                window.tourData.price.prepayment
            );

        });

        /* -------------------------
        Дополнительные услуги
        ------------------------- */

        const servicesContainer =
        this.container.querySelector(".services-list");

        this.data.services.forEach((service,index)=>{

            const row = document.createElement("div");

            row.className="service-row";

            row.innerHTML=`

                <input
                    type="text"
                    class="service-title"
                    placeholder="Название услуги"
                    value="${service.title}">

                <input
                    type="number"
                    class="service-price"
                    placeholder="Стоимость"
                    value="${service.price}">

                <button
                    class="remove-service">

                    🗑

                </button>

            `;

            servicesContainer.appendChild(row);

            /* Название */

            row.querySelector(".service-title")

                .addEventListener("input",(e)=>{

                    this.data.services[index].title =
                        e.target.value;

                    window.saveTourData();

                    console.log(
                        "Дополнительная услуга:",
                        window.tourData.price.services[index].title
                    );

            });

            /* Цена */

            row.querySelector(".service-price")

                .addEventListener("input",(e)=>{

                    this.data.services[index].price =
                        Number(e.target.value);

                    window.saveTourData();

                    console.log(
                        "Стоимость услуги:",
                        window.tourData.price.services[index].price
                    );

                    this.updateSummary();

            });

            /* Удаление */

            row.querySelector(".remove-service")

                .addEventListener("click",()=>{

                    this.removeService(index);

                });

        });

        this.container.querySelector(".add-service")

        .addEventListener("click",()=>{

            this.addService();

        });

    }

    addService() {

        this.data.services.push({

            title: "",

            price: 0

        });

        window.saveTourData();

        this.render();

    }

    removeService(index) {

        this.data.services.splice(index,1);

        window.saveTourData();

        this.render();

    }

    getServicesTotal() {

        return this.data.services.reduce((sum, item) => {

            return sum + Number(item.price || 0);

        }, 0);

    }

    getTotalAdult(){

        return Number(this.data.adult) +
            this.getServicesTotal();

    }

    getTotalChild(){

        return Number(this.data.child) +
            this.getServicesTotal();

    }

    updateSummary(){

        this.container.querySelector(".summary-adult").textContent =

            `${this.data.adult} ${this.data.currency}`;

        this.container.querySelector(".summary-child").textContent =

            `${this.data.child} ${this.data.currency}`;

        this.container.querySelector(".summary-services").textContent =

            `${this.getServicesTotal()} ${this.data.currency}`;

        this.container.querySelector(".summary-total-adult").textContent =

            `${this.getTotalAdult()} ${this.data.currency}`;

        this.container.querySelector(".summary-total-child").textContent =

            `${this.getTotalChild()} ${this.data.currency}`;

    }

}

export default PriceBuilder;