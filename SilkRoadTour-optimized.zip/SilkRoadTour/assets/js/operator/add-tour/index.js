import TourWizard from "./wizard.js";

import RouteBuilder from "./route-builder.js";

import ProgramBuilder from "./program-builder.js";

/*import TourModel from "../models/tour-model.js";*/

import PriceBuilder from "./PriceBuilder.js";

import GalleryBuilder from "./GalleryBuilder.js";

import PublicationBuilder from "./PublicationBuilder.js";

document.addEventListener("DOMContentLoaded", () => {

    /* =========================
       Единые данные тура
    ========================= 

    const tourData = {

        basic: {},

        route: [],

        program: [],

        price: {},

        gallery: [],

        publication: {}

    };

     Делаем данные доступными для остальных Builder'ов 

    window.tourData = tourData;
    */

    /* =========================
    Единые данные тура
    ========================= */

    const savedTourData =
        localStorage.getItem("tourData");

    if (savedTourData) {

        window.tourData =
            JSON.parse(savedTourData);

        console.log(
            "Данные тура восстановлены:",
            window.tourData
        );

    } else {

        window.tourData = {

            basic: {},

            route: [],

            program: [],

            price: {},

            gallery: [],

            publication: {}

        };

        console.log(
            "Создан новый tourData"
        );

    }

    /* =========================
    Сохранение данных тура
    ========================= */

    window.saveTourData = function () {

        localStorage.setItem(
            "tourData",
            JSON.stringify(window.tourData)
        );

    };


    /* =========================
       Builder'ы
    ========================= */

    new TourWizard();

    new RouteBuilder();

    new ProgramBuilder();

    new PriceBuilder();

    new GalleryBuilder();

    window.publicationBuilder =
        new PublicationBuilder();

    /* =========================
    Шаг 1 — Основная информация
    ========================= */

    const titleInput =
        document.querySelector(".tour-title");

    if (titleInput) {

        titleInput.addEventListener("input", () => {

            window.tourData.basic.title =
                titleInput.value;

            window.saveTourData();

            console.log(
                "Название тура:",
                window.tourData.basic.title
            );

        });

    }

    /* =========================
    Краткое описание
    ========================= */

    const shortDescriptionInput =
        document.querySelector(".tour-short-description");

    if (shortDescriptionInput) {

        shortDescriptionInput.addEventListener("input", () => {

            window.tourData.basic.shortDescription =
                shortDescriptionInput.value;

            window.saveTourData();

            console.log(
                "Краткое описание:",
                window.tourData.basic.shortDescription
            );

        });

    }

    /* =========================
    Полное описание
    ========================= */

    const fullDescriptionInput =
        document.querySelector(".tour-full-description");

    if (fullDescriptionInput) {

        fullDescriptionInput.addEventListener("input", () => {

            window.tourData.basic.fullDescription =
                fullDescriptionInput.value;

            window.saveTourData();

            console.log(
                "Полное описание:",
                window.tourData.basic.fullDescription
            );

        });

    }

    /* =========================
    Направление
    ========================= */

    const directionInput =
        document.querySelector(".tour-direction");

    if (directionInput) {

        directionInput.addEventListener("change", () => {

            window.tourData.basic.direction =
                directionInput.value;

            window.saveTourData();

            console.log(
                "Направление:",
                window.tourData.basic.direction
            );

        });

        /* Сохраняем значение,
        выбранное по умолчанию */

        window.tourData.basic.direction =
            directionInput.value;

    }

    /* =========================
    Категория
    ========================= */

    const categoryInput =
        document.querySelector(".tour-category");

    if (categoryInput) {

        categoryInput.addEventListener("change", () => {

            window.tourData.basic.category =
                categoryInput.value;

            window.saveTourData();

            console.log(
                "Категория:",
                window.tourData.basic.category
            );

        });

        /* Сохраняем значение
        по умолчанию */

        window.tourData.basic.category =
            categoryInput.value;

    }

    /* =========================
    Продолжительность
    ========================= */

    const durationInput =
        document.querySelector(".tour-duration");

    if (durationInput) {

        durationInput.addEventListener("input", () => {

            window.tourData.basic.duration =
                Number(durationInput.value) || 0;

            window.saveTourData();

            console.log(
                "Продолжительность:",
                window.tourData.basic.duration
            );

        });

    }

    /* =========================
    Язык экскурсии
    ========================= */

    const languageInput =
        document.querySelector(".tour-language");

    if (languageInput) {

        languageInput.addEventListener("change", () => {

            window.tourData.basic.language =
                languageInput.value;

            window.saveTourData();

            console.log(
                "Язык экскурсии:",
                window.tourData.basic.language
            );

        });

        /* Сохраняем значение
        по умолчанию */

        window.tourData.basic.language =
            languageInput.value;

    }

    /* =========================
    Максимум туристов
    ========================= */

    const maxTouristsInput =
        document.querySelector(".tour-max-tourists");

    if (maxTouristsInput) {

        maxTouristsInput.addEventListener("input", () => {

            window.tourData.basic.maxTourists =
                Number(maxTouristsInput.value) || 0;

            window.saveTourData();

            console.log(
                "Максимум туристов:",
                window.tourData.basic.maxTourists
            );

        });

    }

    /* =========================
    Минимальный возраст
    ========================= */

    const minAgeInput =
        document.querySelector(".tour-min-age");

    if (minAgeInput) {

        minAgeInput.addEventListener("input", () => {

            window.tourData.basic.minAge =
                Number(minAgeInput.value) || 0;

            window.saveTourData();

            console.log(
                "Минимальный возраст:",
                window.tourData.basic.minAge
            );

        });

    }

    /* =========================
    Уровень сложности
    ========================= */

    const difficultyInput =
        document.querySelector(".tour-difficulty");

    if (difficultyInput) {

        difficultyInput.addEventListener("change", () => {

            window.tourData.basic.difficulty =
                difficultyInput.value;

            window.saveTourData();

            console.log(
                "Уровень сложности:",
                window.tourData.basic.difficulty
            );

        });

        /* Сохраняем значение
        по умолчанию */

        window.tourData.basic.difficulty =
            difficultyInput.value;

    }

    /* =========================
    Статус тура
    ========================= */

    const statusInput =
        document.querySelector(".tour-status");

    if (statusInput) {

        statusInput.addEventListener("change", () => {

            window.tourData.basic.status =
                statusInput.value;

            window.saveTourData();

            console.log(
                "Статус тура:",
                window.tourData.basic.status
            );

        });

        /* Сохраняем значение
        по умолчанию */

        window.tourData.basic.status =
            statusInput.value;

    }

});



/*
document.addEventListener("DOMContentLoaded", () => {

    new TourWizard();
    
    new RouteBuilder();

    new ProgramBuilder();

    new PriceBuilder();

    new GalleryBuilder();

    window.publicationBuilder = 
        new PublicationBuilder();

});*/


