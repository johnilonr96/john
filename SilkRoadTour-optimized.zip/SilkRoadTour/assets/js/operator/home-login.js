(function () {
    "use strict";

    const OPERATOR_EMAIL =
        "operator@silkroad.uz";

    const OPERATOR_PASSWORD =
        "12345678";


    function initOperatorHomeLogin() {

        const openButton =
            document.getElementById(
                "operatorLoginOpen"
            );

        const modal =
            document.getElementById(
                "operatorHomeLoginModal"
            );

        const closeButton =
            document.getElementById(
                "operatorHomeLoginClose"
            );

        const overlay =
            modal?.querySelector(
                "[data-operator-login-close]"
            );

        const form =
            document.getElementById(
                "operatorHomeLoginForm"
            );

        const emailInput =
            document.getElementById(
                "operatorHomeEmail"
            );

        const passwordInput =
            document.getElementById(
                "operatorHomePassword"
            );

        const passwordToggle =
            document.getElementById(
                "operatorHomePasswordToggle"
            );

        const errorBox =
            document.getElementById(
                "operatorHomeLoginError"
            );


        if (
            !openButton ||
            !modal ||
            !form ||
            !emailInput ||
            !passwordInput
        ) {

            console.error(
                "Не найдены элементы окна входа оператора."
            );

            return;
        }


        function showError(message) {

            if (!errorBox) {
                return;
            }

            errorBox.textContent =
                message;

            errorBox.hidden =
                !message;
        }


        function openModal() {

            if (
                localStorage.getItem(
                    "operatorLoggedIn"
                ) === "true"
            ) {

                window.location.href =
                    "pages/operator/dashboard.html";

                return;
            }


            showError("");

            modal.hidden =
                false;

            document.body.classList.add(
                "operator-login-modal-open"
            );


            const savedEmail =
                localStorage.getItem(
                    "operatorEmail"
                );

            if (savedEmail) {
                emailInput.value =
                    savedEmail;
            }


            setTimeout(
                function () {
                    emailInput.focus();
                },
                0
            );
        }


        function closeModal() {

            modal.hidden =
                true;

            document.body.classList.remove(
                "operator-login-modal-open"
            );

            showError("");

            passwordInput.value =
                "";

            passwordInput.type =
                "password";

            if (passwordToggle) {
                passwordToggle.textContent =
                    "👁";
            }
        }


        openButton.addEventListener(
            "click",
            openModal
        );


        closeButton?.addEventListener(
            "click",
            closeModal
        );


        overlay?.addEventListener(
            "click",
            closeModal
        );


        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape" &&
                    !modal.hidden
                ) {

                    closeModal();
                }
            }
        );


        passwordToggle?.addEventListener(
            "click",
            function () {

                const showPassword =
                    passwordInput.type ===
                    "password";


                passwordInput.type =
                    showPassword
                        ? "text"
                        : "password";


                passwordToggle.textContent =
                    showPassword
                        ? "🙈"
                        : "👁";
            }
        );


        form.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                showError("");


                const email =
                    emailInput.value
                        .trim()
                        .toLowerCase();


                const password =
                    passwordInput.value;


                if (
                    email ===
                        OPERATOR_EMAIL &&
                    password ===
                        OPERATOR_PASSWORD
                ) {

                    localStorage.setItem(
                        "operatorLoggedIn",
                        "true"
                    );


                    localStorage.setItem(
                        "operatorEmail",
                        email
                    );


                    window.location.href =
                        "pages/operator/dashboard.html";

                    return;
                }


                showError(
                    "Неверный логин или пароль."
                );

                passwordInput.focus();
                passwordInput.select();
            }
        );


        console.log(
            "✅ Вход оператора с главной страницы подключён."
        );
    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initOperatorHomeLogin
        );

    } else {

        initOperatorHomeLogin();
    }

})();
