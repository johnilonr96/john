document.addEventListener(
    "DOMContentLoaded",
    function () {

        const passwordInput =
            document.getElementById(
                "operatorPassword"
            );

        const passwordToggle =
            document.getElementById(
                "passwordToggle"
            );


        if (
            !passwordInput ||
            !passwordToggle
        ) {
            return;
        }

        // =========================================
        // Показать / скрыть пароль
        // ========================================

        passwordToggle.addEventListener(
            "click",
            function () {

                if (
                    passwordInput.type ===
                    "password"
                ) {

                    passwordInput.type =
                        "text";

                    passwordToggle.textContent =
                        "🙈";

                } else {

                    passwordInput.type =
                        "password";

                    passwordToggle.textContent =
                        "👁";

                }

            }
        );

        // =========================================
        // Вход туроператора
        // =========================================

        const loginForm =
            document.getElementById(
                "operatorLoginForm"
            );

        const emailInput =
            document.getElementById(
                "operatorEmail"
            );

        const loginError =
            document.getElementById(
                "loginError"
            );


        if (loginForm) {

            loginForm.addEventListener(
                "submit",
                function (event) {

                    event.preventDefault();


                    const email =
                        emailInput.value
                            .trim()
                            .toLowerCase();

                    const password =
                        passwordInput.value;


                    // Временные данные для входа
                    const operatorEmail =
                        "operator@silkroad.uz";

                    const operatorPassword =
                        "12345678";


                    if (
                        email === operatorEmail &&
                        password === operatorPassword
                    ) {

                        localStorage.setItem(
                            "operatorLoggedIn",
                            "true"
                        );


                        localStorage.setItem(
                            "operatorEmail",
                            email
                        );


                        window.location.href =
                            "dashboard.html";

                    } else {

                        loginError.textContent =
                            "Неверный Email или пароль.";

                        loginError.hidden =
                            false;

                    }

                }
            );

        }

    }
    
);