const operatorLoggedIn =
    localStorage.getItem(
        "operatorLoggedIn"
    );


if (
    operatorLoggedIn !== "true"
) {

    window.location.replace(
        "login.html"
    );

}

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const logoutButton =
            document.getElementById(
                "operatorLogout"
            );


        if (!logoutButton) {
            return;
        }


        logoutButton.addEventListener(
            "click",
            function (event) {

                event.preventDefault();


                localStorage.removeItem(
                    "operatorLoggedIn"
                );


                localStorage.removeItem(
                    "operatorEmail"
                );


                window.location.replace(
                    "login.html"
                );

            }
        );

    }
);