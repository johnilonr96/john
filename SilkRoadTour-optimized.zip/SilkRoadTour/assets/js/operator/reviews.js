document.addEventListener(
    "DOMContentLoaded",
    function () {

        const STORAGE_KEY =
            "reviews";


        const list =
            document.getElementById(
                "reviewsList"
            );

        const emptyState =
            document.getElementById(
                "reviewsEmpty"
            );

        const searchInput =
            document.getElementById(
                "reviewSearch"
            );

        const statusFilter =
            document.getElementById(
                "reviewStatusFilter"
            );

        const ratingFilter =
            document.getElementById(
                "reviewRatingFilter"
            );

        const totalReviews =
            document.getElementById(
                "totalReviews"
            );

        const pendingReviews =
            document.getElementById(
                "pendingReviews"
            );

        const publishedReviews =
            document.getElementById(
                "publishedReviews"
            );

        const averageRating =
            document.getElementById(
                "averageRating"
            );

        const modal =
            document.getElementById(
                "reviewDetailsModal"
            );

        const modalContent =
            document.getElementById(
                "reviewModalContent"
            );

        const modalClose =
            document.getElementById(
                "reviewModalClose"
            );

        const modalOverlay =
            modal?.querySelector(
                "[data-review-modal-close]"
            );


        let reviews = [];


        function readReviews() {

            try {

                const data =
                    JSON.parse(
                        localStorage.getItem(
                            STORAGE_KEY
                        )
                    );

                reviews =
                    Array.isArray(data)
                        ? data
                        : [];

            } catch (error) {

                console.error(
                    "Ошибка чтения reviews:",
                    error
                );

                reviews = [];
            }
        }


        function saveReviews() {

            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(reviews)
            );
        }


        function escapeHtml(value) {

            return String(
                value ?? ""
            )
                .replaceAll("&", "&amp;")
                .replaceAll("<", "&lt;")
                .replaceAll(">", "&gt;")
                .replaceAll('"', "&quot;")
                .replaceAll("'", "&#039;");
        }


        function normalizedStatus(review) {

            if (
                review?.status ===
                "published"
            ) {
                return "published";
            }

            if (
                review?.status ===
                "hidden"
            ) {
                return "hidden";
            }

            return "pending";
        }


        function statusText(status) {

            if (
                status ===
                "published"
            ) {
                return "Опубликовано";
            }

            if (
                status ===
                "hidden"
            ) {
                return "Скрыто";
            }

            return "На проверке";
        }


        function normalizedRating(value) {

            const rating =
                Math.round(
                    Number(value) || 0
                );

            return Math.min(
                5,
                Math.max(
                    1,
                    rating || 1
                )
            );
        }


        function stars(value) {

            const rating =
                normalizedRating(
                    value
                );

            return (
                "★".repeat(rating) +
                "☆".repeat(5 - rating)
            );
        }


        function formatDate(value) {

            if (!value) {
                return "—";
            }

            const date =
                new Date(value);

            if (
                Number.isNaN(
                    date.getTime()
                )
            ) {
                return String(value);
            }

            return date.toLocaleString(
                "ru-RU",
                {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );
        }


        function bookingNumber(id) {

            if (!id) {
                return "—";
            }

            return (
                "#" +
                String(id).slice(-8)
            );
        }


        function authorName(review) {

            return (
                review?.tourist?.fullName ||
                review?.fullName ||
                "Турист"
            );
        }


        function authorEmail(review) {

            return (
                review?.tourist?.email ||
                review?.email ||
                ""
            );
        }


        function initials(name) {

            const parts =
                String(name || "Т")
                    .trim()
                    .split(/\s+/)
                    .filter(Boolean);

            if (!parts.length) {
                return "Т";
            }

            return parts
                .slice(0, 2)
                .map(
                    item =>
                        item.charAt(0)
                            .toUpperCase()
                )
                .join("");
        }


        function updateStats() {

            if (totalReviews) {
                totalReviews.textContent =
                    reviews.length;
            }


            if (pendingReviews) {
                pendingReviews.textContent =
                    reviews.filter(
                        item =>
                            normalizedStatus(
                                item
                            ) ===
                            "pending"
                    ).length;
            }


            if (publishedReviews) {
                publishedReviews.textContent =
                    reviews.filter(
                        item =>
                            normalizedStatus(
                                item
                            ) ===
                            "published"
                    ).length;
            }


            if (averageRating) {

                if (!reviews.length) {

                    averageRating.textContent =
                        "0.0";

                } else {

                    const average =
                        reviews.reduce(
                            (sum, item) =>
                                sum +
                                normalizedRating(
                                    item.rating
                                ),
                            0
                        ) /
                        reviews.length;


                    averageRating.textContent =
                        average.toFixed(1);
                }
            }
        }


        function filteredReviews() {

            const query =
                searchInput
                    ?.value
                    .trim()
                    .toLowerCase() || "";


            const wantedStatus =
                statusFilter
                    ?.value ||
                "all";


            const wantedRating =
                ratingFilter
                    ?.value ||
                "all";


            return reviews
                .filter(
                    review => {

                        const status =
                            normalizedStatus(
                                review
                            );

                        if (
                            wantedStatus !==
                                "all" &&
                            status !==
                                wantedStatus
                        ) {
                            return false;
                        }


                        if (
                            wantedRating !==
                                "all" &&
                            normalizedRating(
                                review.rating
                            ) !==
                                Number(
                                    wantedRating
                                )
                        ) {
                            return false;
                        }


                        if (!query) {
                            return true;
                        }


                        const haystack =
                            [
                                authorName(review),
                                authorEmail(review),
                                review?.tourist?.country,
                                review?.tourTitle,
                                review?.text,
                                review?.comment,
                                bookingNumber(
                                    review?.bookingId
                                )
                            ]
                                .filter(Boolean)
                                .join(" ")
                                .toLowerCase();


                        return haystack
                            .includes(query);
                    }
                )
                .sort(
                    (a, b) =>
                        new Date(
                            b.createdAt || 0
                        ) -
                        new Date(
                            a.createdAt || 0
                        )
                );
        }


        function reviewText(review) {

            return (
                review?.text ||
                review?.comment ||
                "Без комментария."
            );
        }


        function actionButtons(review) {

            const status =
                normalizedStatus(
                    review
                );


            const buttons = [
                `
                    <button
                        type="button"
                        class="review-action"
                        data-review-action="view"
                        data-review-id="${escapeHtml(review.id)}">
                        👁 Просмотр
                    </button>
                `
            ];


            if (
                status !==
                "published"
            ) {

                buttons.push(
                    `
                        <button
                            type="button"
                            class="review-action review-action--publish"
                            data-review-action="publish"
                            data-review-id="${escapeHtml(review.id)}">
                            ✓ Опубликовать
                        </button>
                    `
                );
            }


            if (
                status !==
                "hidden"
            ) {

                buttons.push(
                    `
                        <button
                            type="button"
                            class="review-action review-action--hide"
                            data-review-action="hide"
                            data-review-id="${escapeHtml(review.id)}">
                            Скрыть
                        </button>
                    `
                );
            }


            return buttons.join("");
        }


        function render() {

            const filtered =
                filteredReviews();


            updateStats();


            if (!list) {
                return;
            }


            if (!filtered.length) {

                list.innerHTML = "";

                if (emptyState) {
                    emptyState.hidden =
                        false;
                }

                return;
            }


            if (emptyState) {
                emptyState.hidden =
                    true;
            }


            list.innerHTML =
                filtered
                    .map(
                        review => {

                            const name =
                                authorName(
                                    review
                                );

                            const status =
                                normalizedStatus(
                                    review
                                );

                            return `
                                <article class="review-card">

                                    <div class="review-card__top">

                                        <div class="review-card__author">

                                            <div class="review-card__avatar">
                                                ${escapeHtml(initials(name))}
                                            </div>

                                            <div>
                                                <h4>
                                                    ${escapeHtml(name)}
                                                </h4>

                                                <p>
                                                    ${escapeHtml(authorEmail(review) || "Email не указан")}
                                                </p>
                                            </div>

                                        </div>


                                        <div class="review-card__meta">

                                            <span class="review-rating">
                                                ${stars(review.rating)}
                                            </span>

                                            <span class="review-status review-status--${status}">
                                                ${statusText(status)}
                                            </span>

                                        </div>

                                    </div>


                                    <div class="review-card__tour">

                                        <span>
                                            Тур:
                                            <strong>
                                                ${escapeHtml(review.tourTitle || "—")}
                                            </strong>
                                        </span>

                                        <span>
                                            Бронь:
                                            <strong>
                                                ${escapeHtml(bookingNumber(review.bookingId))}
                                            </strong>
                                        </span>

                                    </div>


                                    <p class="review-card__text">
                                        ${escapeHtml(reviewText(review))}
                                    </p>


                                    <div class="review-card__footer">

                                        <span class="review-card__date">
                                            ${escapeHtml(formatDate(review.createdAt))}
                                        </span>

                                        <div class="review-actions">
                                            ${actionButtons(review)}
                                        </div>

                                    </div>

                                </article>
                            `;
                        }
                    )
                    .join("");
        }


        function findReview(id) {

            return reviews.find(
                item =>
                    String(item?.id) ===
                    String(id)
            );
        }


        function changeStatus(
            id,
            status
        ) {

            const review =
                findReview(id);

            if (!review) {
                return;
            }


            review.status =
                status;

            review.updatedAt =
                new Date()
                    .toISOString();


            saveReviews();

            render();
        }


        function openModal(review) {

            if (
                !modal ||
                !modalContent ||
                !review
            ) {
                return;
            }


            const status =
                normalizedStatus(
                    review
                );


            modalContent.innerHTML = `
                <h2 class="review-modal__title">
                    Отзыв туриста
                </h2>

                <div class="review-modal__grid">

                    <div class="review-modal__item">
                        <span>Турист</span>
                        <strong>
                            ${escapeHtml(authorName(review))}
                        </strong>
                    </div>

                    <div class="review-modal__item">
                        <span>Email</span>
                        <strong>
                            ${escapeHtml(authorEmail(review) || "—")}
                        </strong>
                    </div>

                    <div class="review-modal__item">
                        <span>Тур</span>
                        <strong>
                            ${escapeHtml(review.tourTitle || "—")}
                        </strong>
                    </div>

                    <div class="review-modal__item">
                        <span>Бронирование</span>
                        <strong>
                            ${escapeHtml(bookingNumber(review.bookingId))}
                        </strong>
                    </div>

                    <div class="review-modal__item">
                        <span>Оценка</span>
                        <strong>
                            ${stars(review.rating)}
                            (${normalizedRating(review.rating)}/5)
                        </strong>
                    </div>

                    <div class="review-modal__item">
                        <span>Статус</span>
                        <strong>
                            ${statusText(status)}
                        </strong>
                    </div>

                </div>

                <div class="review-modal__text">
                    ${escapeHtml(reviewText(review))}
                </div>
            `;


            modal.hidden =
                false;

            document.body.style.overflow =
                "hidden";
        }


        function closeModal() {

            if (!modal) {
                return;
            }

            modal.hidden =
                true;

            document.body.style.overflow =
                "";
        }


        list?.addEventListener(
            "click",
            function (event) {

                const button =
                    event.target.closest(
                        "[data-review-action]"
                    );

                if (!button) {
                    return;
                }


                const id =
                    button.dataset.reviewId;

                const action =
                    button.dataset.reviewAction;


                if (
                    action === "view"
                ) {

                    openModal(
                        findReview(id)
                    );

                    return;
                }


                if (
                    action === "publish"
                ) {

                    changeStatus(
                        id,
                        "published"
                    );

                    return;
                }


                if (
                    action === "hide"
                ) {

                    changeStatus(
                        id,
                        "hidden"
                    );
                }
            }
        );


        searchInput?.addEventListener(
            "input",
            render
        );


        statusFilter?.addEventListener(
            "change",
            render
        );


        ratingFilter?.addEventListener(
            "change",
            render
        );


        modalClose?.addEventListener(
            "click",
            closeModal
        );


        modalOverlay?.addEventListener(
            "click",
            closeModal
        );


        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key ===
                        "Escape" &&
                    modal &&
                    !modal.hidden
                ) {
                    closeModal();
                }
            }
        );


        window.addEventListener(
            "storage",
            function (event) {

                if (
                    event.key ===
                    STORAGE_KEY
                ) {

                    readReviews();

                    render();
                }
            }
        );


        readReviews();

        render();


        console.log(
            "✅ Страница отзывов оператора подключена."
        );
    }
);
