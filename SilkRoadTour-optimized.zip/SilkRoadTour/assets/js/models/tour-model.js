class TourModel {

    constructor() {

        this.reset();

    }

    reset() {

        this.data = {

            /* -------------------------
               Шаг 1
            ------------------------- */

            general: {

                title: "",
                country: "",
                city: "",
                duration: "",
                season: "",
                description: ""

            },

            /* -------------------------
               Шаг 2
            ------------------------- */

            route: [],

            /* -------------------------
               Шаг 3
            ------------------------- */

            program: [],

            /* -------------------------
               Шаг 4
            ------------------------- */

            price: {

                adult: 0,
                child: 0,
                currency: "USD",
                prepayment: 0,
                included: [],
                services: []

            },

            /* -------------------------
               Шаг 5
            ------------------------- */

            gallery: []

        };

    }

}

export default new TourModel();