(function () {
    "use strict";

    const STORAGE_KEY = "bookings";
    const REVIEWS_KEY = "reviews";

    function readBookings() {
        try {
            const data =
                JSON.parse(
                    localStorage.getItem(
                        STORAGE_KEY
                    )
                );

            return Array.isArray(data)
                ? data
                : [];

        } catch (error) {

            console.error(
                "Ошибка чтения bookings:",
                error
            );

            return [];
        }
    }


    function saveBookings(bookings) {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(bookings)
        );
    }


    function readReviews() {

        try {
            const data =
                JSON.parse(
                    localStorage.getItem(
                        REVIEWS_KEY
                    )
                );

            return Array.isArray(data)
                ? data
                : [];

        } catch (error) {

            console.error(
                "Ошибка чтения reviews:",
                error
            );

            return [];
        }
    }


    function saveReviews(reviews) {

        localStorage.setItem(
            REVIEWS_KEY,
            JSON.stringify(reviews)
        );
    }


    function isTourCompleted(booking) {

        if (
            booking?.status ===
            "completed"
        ) {
            return true;
        }

        if (
            booking?.status ===
            "cancelled"
        ) {
            return false;
        }

        if (!booking?.date) {
            return false;
        }

        const tourDate =
            new Date(
                booking.date +
                "T23:59:59"
            );

        if (
            Number.isNaN(
                tourDate.getTime()
            )
        ) {
            return false;
        }

        return tourDate.getTime() <
            Date.now();
    }


    function bookingState(booking) {

        if (
            booking?.status ===
            "cancelled"
        ) {
            return "cancelled";
        }

        if (
            isTourCompleted(
                booking
            )
        ) {
            return "completed";
        }

        if (
            booking?.status ===
            "confirmed"
        ) {
            return "confirmed";
        }

        return "new";
    }


    function bookingStateText(booking) {

        const state =
            bookingState(
                booking
            );

        if (
            state ===
            "completed"
        ) {
            return "Завершено";
        }

        return statusText(
            state
        );
    }


    function escapeHtml(value) {

        return String(
            value ?? ""
        )
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    function reviewStars(rating) {

        const value =
            Math.max(
                1,
                Math.min(
                    5,
                    Number(rating) || 1
                )
            );

        return (
            "★".repeat(value) +
            "☆".repeat(5 - value)
        );
    }


    function bookingNumber(id) {

        if (!id) {
            return "—";
        }

        return (
            "#" +
            String(id).slice(-8)
        );
    }


    function formatTourDate(value) {

        if (!value) {
            return "—";
        }

        const parts =
            String(value)
                .split("-");

        if (
            parts.length !== 3
        ) {
            return value;
        }

        return (
            parts[2] +
            "." +
            parts[1] +
            "." +
            parts[0]
        );
    }


    function formatCreated(value, id) {

        const date =
            value
                ? new Date(value)
                : new Date(
                    Number(id) || 0
                );

        if (
            Number.isNaN(
                date.getTime()
            )
        ) {
            return "—";
        }

        return date.toLocaleString(
            "ru-RU",
            {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            }
        );
    }


    function statusText(status) {

        if (
            status === "confirmed"
        ) {
            return "Подтверждено";
        }

        if (
            status === "completed"
        ) {
            return "Завершено";
        }

        if (
            status === "cancelled"
        ) {
            return "Отменено";
        }

        return "Новое";
    }


    function formatPrice(
        value,
        currency
    ) {

        return (
            (Number(value) || 0)
                .toLocaleString("ru-RU")
            +
            " "
            +
            (currency || "USD")
        );
    }


    function initMyBooking() {

        const form =
            document.getElementById(
                "bookingSearchForm"
            );

        const numberInput =
            document.getElementById(
                "bookingNumberInput"
            );

        const emailInput =
            document.getElementById(
                "bookingEmailInput"
            );

        const errorBox =
            document.getElementById(
                "bookingSearchError"
            );

        const result =
            document.getElementById(
                "bookingResult"
            );

        const saveButton =
            document.getElementById(
                "saveBookingChanges"
            );

        const cancelButton =
            document.getElementById(
                "cancelBookingButton"
            );

        const cancelModal =
            document.getElementById(
                "cancelBookingModal"
            );

        const cancelBack =
            document.getElementById(
                "cancelBookingBack"
            );

        const cancelConfirm =
            document.getElementById(
                "cancelBookingConfirm"
            );

        const cancelReasonInput =
            document.getElementById(
                "cancelBookingReason"
            );

        const cancelReasonError =
            document.getElementById(
                "cancelBookingReasonError"
            );

        const fullNameInput =
            document.getElementById(
                "clientFullName"
            );

        const phoneInput =
            document.getElementById(
                "clientPhone"
            );

        const clientEmailInput =
            document.getElementById(
                "clientEmail"
            );

        const countryInput =
            document.getElementById(
                "clientCountry"
            );

        const reviewSection =
            document.getElementById(
                "bookingReviewSection"
            );

        const reviewForm =
            document.getElementById(
                "bookingReviewForm"
            );

        const reviewStarsBox =
            document.getElementById(
                "bookingReviewStars"
            );

        const reviewTextInput =
            document.getElementById(
                "bookingReviewText"
            );

        const reviewError =
            document.getElementById(
                "bookingReviewError"
            );

        const reviewSubmit =
            document.getElementById(
                "submitBookingReview"
            );

        const reviewDone =
            document.getElementById(
                "bookingReviewDone"
            );

        const historySection =
            document.getElementById(
                "bookingHistory"
            );

        const historyTabs =
            document.getElementById(
                "bookingHistoryTabs"
            );

        const historyList =
            document.getElementById(
                "bookingHistoryList"
            );

        const historyEmpty =
            document.getElementById(
                "bookingHistoryEmpty"
            );

        let selectedReviewRating =
            0;

        let currentHistoryEmail =
            "";

        let currentHistoryFilter =
            "all";


        if (
            !form ||
            !numberInput ||
            !emailInput ||
            !result
        ) {

            console.error(
                "Не найдены элементы страницы my-booking."
            );

            return;
        }


        function showError(message) {

            if (!errorBox) {
                return;
            }

            errorBox.textContent =
                message;

            errorBox.hidden =
                !message;
        }


        function updateCancelButton(booking) {

            if (!cancelButton) {
                return;
            }

            const cancelled =
                booking?.status ===
                "cancelled";

            const completed =
                isTourCompleted(
                    booking
                );

            cancelButton.disabled =
                cancelled ||
                completed;

            cancelButton.textContent =
                cancelled
                    ? "Бронирование отменено"
                    : completed
                        ? "Тур завершён"
                        : "Отменить бронирование";
        }


        function showReviewError(message) {

            if (!reviewError) {
                return;
            }

            reviewError.textContent =
                message;

            reviewError.hidden =
                !message;
        }


        function paintReviewStars() {

            reviewStarsBox
                ?.querySelectorAll(
                    "[data-rating]"
                )
                .forEach(
                    button => {

                        const value =
                            Number(
                                button.dataset.rating
                            );

                        button.classList.toggle(
                            "is-active",
                            value <=
                                selectedReviewRating
                        );
                    }
                );
        }


        function existingReviewForBooking(
            bookingId
        ) {

            return readReviews()
                .find(
                    item =>
                        String(
                            item?.bookingId
                        ) ===
                        String(
                            bookingId
                        )
                );
        }


        function updateReviewSection(
            booking
        ) {

            if (!reviewSection) {
                return;
            }

            const allowed =
                isTourCompleted(
                    booking
                );

            reviewSection.hidden =
                !allowed;


            if (!allowed) {
                return;
            }


            const existing =
                existingReviewForBooking(
                    booking.id
                );


            if (existing) {

                if (reviewForm) {
                    reviewForm.hidden =
                        true;
                }

                if (reviewDone) {

                    reviewDone.hidden =
                        false;

                    reviewDone.innerHTML =
                        `
                            <strong>Спасибо! Отзыв уже отправлен.</strong>

                            <span class="my-booking-review__done-stars">
                                ${reviewStars(existing.rating)}
                            </span>

                            <span>
                                ${String(
                                    existing.text || ""
                                )
                                    .replace(/&/g, "&amp;")
                                    .replace(/</g, "&lt;")
                                    .replace(/>/g, "&gt;")}
                            </span>

                            <br><br>

                            <small>
                                Статус:
                                ${
                                    existing.status ===
                                    "published"
                                        ? "Опубликовано"
                                        : existing.status ===
                                          "hidden"
                                            ? "Скрыто"
                                            : "На проверке"
                                }
                            </small>
                        `;
                }

                return;
            }


            if (reviewForm) {
                reviewForm.hidden =
                    false;
            }

            if (reviewDone) {
                reviewDone.hidden =
                    true;
            }

            selectedReviewRating =
                0;

            paintReviewStars();

            if (reviewTextInput) {
                reviewTextInput.value =
                    "";
            }

            showReviewError("");
        }


        function bookingsForEmail(email) {

            const normalizedEmail =
                String(email || "")
                    .trim()
                    .toLowerCase();

            if (!normalizedEmail) {
                return [];
            }

            return readBookings()
                .filter(
                    item =>
                        String(
                            item?.tourist?.email || ""
                        )
                            .trim()
                            .toLowerCase() ===
                        normalizedEmail
                );
        }


        function matchesHistoryFilter(
            booking
        ) {

            const state =
                bookingState(
                    booking
                );

            if (
                currentHistoryFilter ===
                "all"
            ) {
                return true;
            }

            if (
                currentHistoryFilter ===
                "active"
            ) {
                return (
                    state === "new" ||
                    state === "confirmed"
                );
            }

            return (
                state ===
                currentHistoryFilter
            );
        }


        function renderBookingHistory(email) {

            if (
                !historySection ||
                !historyList
            ) {
                return;
            }

            currentHistoryEmail =
                String(email || "")
                    .trim()
                    .toLowerCase();

            if (!currentHistoryEmail) {

                historySection.hidden =
                    true;

                return;
            }


            const bookings =
                bookingsForEmail(
                    currentHistoryEmail
                )
                    .filter(
                        matchesHistoryFilter
                    )
                    .sort(
                        (a, b) => {

                            const dateA =
                                new Date(
                                    a?.date ||
                                    a?.createdAt ||
                                    0
                                )
                                    .getTime();

                            const dateB =
                                new Date(
                                    b?.date ||
                                    b?.createdAt ||
                                    0
                                )
                                    .getTime();

                            return dateB - dateA;
                        }
                    );


            historySection.hidden =
                false;


            if (!bookings.length) {

                historyList.innerHTML =
                    "";

                if (historyEmpty) {
                    historyEmpty.hidden =
                        false;
                }

                return;
            }


            if (historyEmpty) {
                historyEmpty.hidden =
                    true;
            }


            historyList.innerHTML =
                bookings
                    .map(
                        booking => {

                            const state =
                                bookingState(
                                    booking
                                );

                            return `
                                <article class="my-booking-history-card">

                                    <div class="my-booking-history-card__main">

                                        <div class="my-booking-history-card__top">

                                            <h3 class="my-booking-history-card__title">
                                                ${escapeHtml(
                                                    booking?.tourTitle ||
                                                    "Без названия"
                                                )}
                                            </h3>

                                            <span
                                                class="my-booking-history-card__status my-booking-history-card__status--${state}">
                                                ${escapeHtml(
                                                    bookingStateText(
                                                        booking
                                                    )
                                                )}
                                            </span>

                                        </div>

                                        <div class="my-booking-history-card__meta">

                                            <span>
                                                Дата:
                                                <strong>
                                                    ${escapeHtml(
                                                        formatTourDate(
                                                            booking?.date
                                                        )
                                                    )}
                                                </strong>
                                            </span>

                                            <span>
                                                Бронь:
                                                <strong>
                                                    ${escapeHtml(
                                                        bookingNumber(
                                                            booking?.id
                                                        )
                                                    )}
                                                </strong>
                                            </span>

                                            <span>
                                                Туристов:
                                                <strong>
                                                    ${
                                                        Number(
                                                            booking?.tourists
                                                        ) || 1
                                                    }
                                                </strong>
                                            </span>

                                        </div>

                                    </div>

                                    <button
                                        type="button"
                                        class="my-booking-history-card__open"
                                        data-history-open="${escapeHtml(
                                            booking?.id
                                        )}">
                                        Открыть
                                    </button>

                                </article>
                            `;
                        }
                    )
                    .join("");
        }


        function setHistoryFilter(filter) {

            currentHistoryFilter =
                filter || "all";

            historyTabs
                ?.querySelectorAll(
                    "[data-history-filter]"
                )
                .forEach(
                    button => {

                        button.classList.toggle(
                            "is-active",
                            button.dataset
                                .historyFilter ===
                                currentHistoryFilter
                        );
                    }
                );

            renderBookingHistory(
                currentHistoryEmail
            );
        }


        function showBooking(
            booking
        ) {

            document.getElementById(
                "resultTourTitle"
            ).textContent =
                booking.tourTitle ||
                "Ваше бронирование";


            document.getElementById(
                "resultBookingNumber"
            ).textContent =
                bookingNumber(
                    booking.id
                );


            document.getElementById(
                "resultBookingStatus"
            ).textContent =
                bookingStateText(
                    booking
                );


            document.getElementById(
                "resultTourDate"
            ).textContent =
                formatTourDate(
                    booking.date
                );


            document.getElementById(
                "resultTourists"
            ).textContent =
                Number(
                    booking.tourists
                ) || 1;


            document.getElementById(
                "resultPrice"
            ).textContent =
                formatPrice(
                    booking.price,
                    booking.currency
                );


            document.getElementById(
                "resultCreatedAt"
            ).textContent =
                formatCreated(
                    booking.createdAt,
                    booking.id
                );


            const tourist =
                booking.tourist || {};


            if (fullNameInput) {
                fullNameInput.value =
                    tourist.fullName || "";
            }


            if (phoneInput) {
                phoneInput.value =
                    tourist.phone || "";
            }


            if (clientEmailInput) {
                clientEmailInput.value =
                    tourist.email || "";
            }


            if (countryInput) {
                countryInput.value =
                    tourist.country || "";
            }


            result.dataset.bookingId =
                String(
                    booking.id
                );


            updateCancelButton(
                booking
            );


            updateReviewSection(
                booking
            );


            result.hidden =
                false;


            result.scrollIntoView(
                {
                    behavior:
                        "smooth",

                    block:
                        "start"
                }
            );
        }


        function showCancelReasonError(message) {

            if (!cancelReasonError) {
                return;
            }

            cancelReasonError.textContent =
                message;

            cancelReasonError.hidden =
                !message;
        }


        function closeCancelModal() {

            if (!cancelModal) {
                return;
            }

            cancelModal.hidden =
                true;

            showCancelReasonError("");

            if (cancelReasonInput) {
                cancelReasonInput.value = "";
            }
        }


        form.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                showError("");

                result.hidden =
                    true;


                const enteredNumber =
                    numberInput.value
                        .replace(/\D/g, "")
                        .trim();


                const enteredEmail =
                    emailInput.value
                        .trim()
                        .toLowerCase();


                if (
                    !enteredNumber ||
                    !enteredEmail
                ) {

                    showError(
                        "Введите номер брони и email."
                    );

                    return;
                }


                const bookings =
                    readBookings();


                const booking =
                    bookings.find(
                        item => {

                            if (
                                !item ||
                                !item.id
                            ) {
                                return false;
                            }


                            const id =
                                String(
                                    item.id
                                );


                            const numberMatch =
                                id ===
                                    enteredNumber
                                ||
                                id.endsWith(
                                    enteredNumber
                                );


                            const email =
                                String(
                                    item.tourist
                                        ?.email || ""
                                )
                                    .trim()
                                    .toLowerCase();


                            return (
                                numberMatch &&
                                email ===
                                    enteredEmail
                            );
                        }
                    );


                if (!booking) {

                    showError(
                        "Бронирование не найдено. Проверьте номер брони и email."
                    );

                    return;
                }


                currentHistoryFilter =
                    "all";

                setHistoryFilter(
                    "all"
                );

                renderBookingHistory(
                    enteredEmail
                );

                showBooking(
                    booking
                );
            }
        );


        if (saveButton) {

            saveButton.addEventListener(
                "click",
                function () {

                    showError("");


                    const bookingId =
                        result.dataset.bookingId;


                    if (!bookingId) {

                        showError(
                            "Сначала найдите бронирование."
                        );

                        return;
                    }


                    const fullName =
                        fullNameInput
                            ?.value
                            .trim() || "";


                    const phone =
                        phoneInput
                            ?.value
                            .trim() || "";


                    const email =
                        clientEmailInput
                            ?.value
                            .trim() || "";


                    const country =
                        countryInput
                            ?.value
                            .trim() || "";


                    if (
                        !fullName ||
                        !phone ||
                        !email ||
                        !country
                    ) {

                        alert(
                            "Заполните ФИО, телефон, email и страну."
                        );

                        return;
                    }


                    if (
                        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/
                            .test(email)
                    ) {

                        alert(
                            "Введите корректный email."
                        );

                        return;
                    }


                    const bookings =
                        readBookings();


                    const booking =
                        bookings.find(
                            item =>
                                String(
                                    item.id
                                ) ===
                                String(
                                    bookingId
                                )
                        );


                    if (!booking) {

                        alert(
                            "Бронирование не найдено."
                        );

                        return;
                    }


                    booking.tourist = {
                        ...(booking.tourist || {}),

                        fullName:
                            fullName,

                        phone:
                            phone,

                        email:
                            email,

                        country:
                            country
                    };


                    saveBookings(
                        bookings
                    );


                    emailInput.value =
                        email;


                    renderBookingHistory(
                        email
                    );


                    showBooking(
                        booking
                    );


                    const originalText =
                        saveButton.textContent;


                    saveButton.textContent =
                        "Сохранено ✓";

                    saveButton.disabled =
                        true;


                    setTimeout(
                        function () {

                            saveButton.textContent =
                                originalText;

                            saveButton.disabled =
                                false;

                        },
                        1400
                    );


                    console.log(
                        "✅ Данные туриста обновлены:",
                        booking
                    );
                }
            );
        }


        if (
            cancelButton &&
            cancelModal
        ) {

            cancelButton.addEventListener(
                "click",
                function () {

                    if (
                        cancelButton.disabled
                    ) {
                        return;
                    }

                    showCancelReasonError("");

                    if (cancelReasonInput) {
                        cancelReasonInput.value = "";
                    }

                    cancelModal.hidden =
                        false;

                    setTimeout(
                        function () {
                            cancelReasonInput?.focus();
                        },
                        0
                    );
                }
            );
        }


        if (cancelBack) {

            cancelBack.addEventListener(
                "click",
                closeCancelModal
            );
        }


        if (
            cancelModal
        ) {

            cancelModal.addEventListener(
                "click",
                function (event) {

                    if (
                        event.target ===
                        cancelModal
                    ) {

                        closeCancelModal();
                    }
                }
            );
        }


        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape" &&
                    cancelModal &&
                    !cancelModal.hidden
                ) {

                    closeCancelModal();
                }
            }
        );


        if (cancelConfirm) {

            cancelConfirm.addEventListener(
                "click",
                function () {

                    const reason =
                        cancelReasonInput
                            ?.value
                            .trim() || "";


                    if (!reason) {

                        showCancelReasonError(
                            "Укажите причину отмены бронирования."
                        );

                        cancelReasonInput?.focus();

                        return;
                    }


                    showCancelReasonError("");


                    const bookingId =
                        result.dataset.bookingId;


                    if (!bookingId) {

                        closeCancelModal();

                        return;
                    }


                    const bookings =
                        readBookings();


                    const booking =
                        bookings.find(
                            item =>
                                String(
                                    item.id
                                ) ===
                                String(
                                    bookingId
                                )
                        );


                    if (!booking) {

                        closeCancelModal();

                        alert(
                            "Бронирование не найдено."
                        );

                        return;
                    }


                    booking.status =
                        "cancelled";


                    booking.cancelledAt =
                        new Date()
                            .toISOString();


                    booking.cancelledBy =
                        "client";


                    booking.cancelReason =
                        reason;


                    saveBookings(
                        bookings
                    );


                    closeCancelModal();


                    renderBookingHistory(
                        booking?.tourist?.email ||
                        currentHistoryEmail
                    );


                    showBooking(
                        booking
                    );


                    alert(
                        "Бронирование отменено. Причина сохранена."
                    );


                    console.log(
                        "❌ Клиент отменил бронирование:",
                        booking
                    );
                }
            );
        }


        historyTabs?.addEventListener(
            "click",
            function (event) {

                const button =
                    event.target.closest(
                        "[data-history-filter]"
                    );

                if (!button) {
                    return;
                }

                setHistoryFilter(
                    button.dataset
                        .historyFilter
                );
            }
        );


        historyList?.addEventListener(
            "click",
            function (event) {

                const button =
                    event.target.closest(
                        "[data-history-open]"
                    );

                if (!button) {
                    return;
                }

                const booking =
                    readBookings()
                        .find(
                            item =>
                                String(
                                    item?.id
                                ) ===
                                String(
                                    button.dataset
                                        .historyOpen
                                )
                        );

                if (!booking) {
                    return;
                }

                numberInput.value =
                    bookingNumber(
                        booking.id
                    );

                emailInput.value =
                    booking?.tourist?.email ||
                    currentHistoryEmail;

                showError("");

                showBooking(
                    booking
                );
            }
        );


        reviewStarsBox?.addEventListener(
            "click",
            function (event) {

                const button =
                    event.target.closest(
                        "[data-rating]"
                    );

                if (!button) {
                    return;
                }

                selectedReviewRating =
                    Number(
                        button.dataset.rating
                    ) || 0;

                paintReviewStars();

                showReviewError("");
            }
        );


        reviewSubmit?.addEventListener(
            "click",
            function () {

                const bookingId =
                    result.dataset.bookingId;


                if (!bookingId) {

                    showReviewError(
                        "Сначала найдите бронирование."
                    );

                    return;
                }


                const bookings =
                    readBookings();


                const booking =
                    bookings.find(
                        item =>
                            String(item?.id) ===
                            String(bookingId)
                    );


                if (!booking) {

                    showReviewError(
                        "Бронирование не найдено."
                    );

                    return;
                }


                if (
                    !isTourCompleted(
                        booking
                    )
                ) {

                    showReviewError(
                        "Отзыв можно оставить после завершения тура."
                    );

                    return;
                }


                if (
                    existingReviewForBooking(
                        booking.id
                    )
                ) {

                    updateReviewSection(
                        booking
                    );

                    return;
                }


                const text =
                    reviewTextInput
                        ?.value
                        .trim() || "";


                if (
                    selectedReviewRating <
                    1
                ) {

                    showReviewError(
                        "Поставьте оценку от 1 до 5 звёзд."
                    );

                    return;
                }


                if (
                    text.length <
                    5
                ) {

                    showReviewError(
                        "Напишите несколько слов о поездке."
                    );

                    reviewTextInput?.focus();

                    return;
                }


                const reviews =
                    readReviews();


                const review = {
                    id:
                        Date.now(),

                    createdAt:
                        new Date()
                            .toISOString(),

                    status:
                        "pending",

                    bookingId:
                        booking.id,

                    tourTitle:
                        booking.tourTitle || "",

                    rating:
                        selectedReviewRating,

                    text,

                    tourist: {
                        fullName:
                            booking?.tourist
                                ?.fullName || "",

                        phone:
                            booking?.tourist
                                ?.phone || "",

                        email:
                            booking?.tourist
                                ?.email || "",

                        country:
                            booking?.tourist
                                ?.country || ""
                    }
                };


                reviews.push(
                    review
                );


                try {

                    saveReviews(
                        reviews
                    );

                } catch (error) {

                    console.error(
                        "Ошибка сохранения отзыва:",
                        error
                    );

                    showReviewError(
                        "Не удалось сохранить отзыв. Попробуйте ещё раз."
                    );

                    return;
                }


                showReviewError("");

                updateReviewSection(
                    booking
                );


                alert(
                    "Спасибо! Отзыв отправлен оператору на проверку."
                );


                console.log(
                    "⭐ Отзыв сохранён:",
                    review
                );
            }
        );


        function openBookingFromQuickAccess() {
            let quickAccess = null;

            try {
                quickAccess = JSON.parse(
                    sessionStorage.getItem(
                        "bookingQuickAccess"
                    )
                );
            } catch (error) {
                console.error(
                    "Ошибка чтения быстрого доступа к бронированию:",
                    error
                );
            }

            if (
                !quickAccess ||
                !quickAccess.id
            ) {
                return;
            }

            const bookings =
                readBookings();

            const booking =
                bookings.find(
                    item =>
                        String(item?.id) ===
                            String(quickAccess.id)
                        &&
                        String(
                            item?.tourist?.email || ""
                        )
                            .trim()
                            .toLowerCase() ===
                        String(
                            quickAccess.email || ""
                        )
                            .trim()
                            .toLowerCase()
                );

            try {
                sessionStorage.removeItem(
                    "bookingQuickAccess"
                );
            } catch (_) {
                // Ничего критичного.
            }

            if (!booking) {
                showError(
                    "Не удалось автоматически открыть бронирование. Найдите его по номеру и email."
                );

                return;
            }

            numberInput.value =
                bookingNumber(
                    booking.id
                );

            emailInput.value =
                booking?.tourist?.email || "";

            showError("");

            currentHistoryFilter =
                "all";

            setHistoryFilter(
                "all"
            );

            renderBookingHistory(
                booking?.tourist?.email || ""
            );

            showBooking(
                booking
            );
        }


        openBookingFromQuickAccess();


        console.log(
            "✅ Поиск, история поездок, отзывы и управление бронированием подключены."
        );
    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initMyBooking
        );

    } else {

        initMyBooking();
    }

})();
