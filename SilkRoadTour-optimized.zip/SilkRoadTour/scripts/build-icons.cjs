const fs = require("node:fs");
const path = require("node:path");
const esbuild = require("esbuild");
const root = path.resolve(__dirname, "..");
const names = new Set();
function scan(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        if (["node_modules", ".git", "vendor"].includes(entry.name)) continue;
        const file = path.join(directory, entry.name);
        if (entry.isDirectory()) scan(file);
        else if (/\.(html|js)$/.test(entry.name)) {
            const source = fs.readFileSync(file, "utf8");
            for (const pattern of [/data-lucide\s*=\s*["']([a-z0-9-]+)["']/g, /["']data-lucide["']\s*,\s*["']([a-z0-9-]+)["']/g]) {
                for (const match of source.matchAll(pattern)) names.add(match[1]);
            }
        }
    }
}
scan(root);
const icons = [...names].sort().map(name => name.replace(/(^|-)(\w)/g, (_, prefix, letter) => letter.toUpperCase()));
esbuild.buildSync({
    stdin: {
        contents: `import { createIcons as render, ${icons.join(",")} } from 'lucide';
const icons = { ${icons.join(",")} };
export function createIcons(options = {}) { return render({ icons, ...options }); }
export { icons };`,
        resolveDir: root,
        sourcefile: "silkroad-icons.js"
    },
    bundle: true,
    minify: true,
    format: "iife",
    globalName: "lucide",
    outfile: path.join(root, "assets/vendor/lucide/lucide.min.js"),
    banner: { js: "/*! Lucide 0.468.0, ISC license. See LICENSE in this directory. */" }
});
console.log(`Built ${icons.length} icons used by the site.`);
